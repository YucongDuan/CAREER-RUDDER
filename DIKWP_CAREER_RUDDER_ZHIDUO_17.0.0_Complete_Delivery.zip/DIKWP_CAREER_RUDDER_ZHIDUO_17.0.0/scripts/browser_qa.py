#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / 'release' / 'ZHIDUO_2027_Client_17.0.0.html'
ASSETS = ROOT / 'assets'
OUT = ROOT / 'release' / 'BROWSER_QA.json'
ASSETS.mkdir(parents=True, exist_ok=True)

console_errors: list[str] = []
page_errors: list[str] = []
requests: list[str] = []
checks: dict[str, object] = {}

html = HTML.read_text(encoding='utf-8')
with sync_playwright() as p:
    browser = p.chromium.launch(
        headless=True,
        executable_path='/usr/bin/chromium',
        args=['--no-sandbox', '--disable-dev-shm-usage']
    )
    context = browser.new_context(viewport={'width': 1600, 'height': 1000}, locale='zh-CN')
    page = context.new_page()
    page.on('console', lambda msg: console_errors.append(msg.text) if msg.type == 'error' else None)
    page.on('pageerror', lambda err: page_errors.append(str(err)))
    page.on('request', lambda req: requests.append(req.url))

    # set_content validates the fully self-contained build without permitting any
    # file:// or network dependency. The app has an in-memory storage fallback.
    page.set_content(html, wait_until='load')
    page.wait_for_timeout(800)
    checks['title'] = page.title()
    checks['dashboard_active'] = page.locator('#dashboard.view.active').count() == 1
    checks['metric_cards'] = page.locator('#dashboardMetrics .metric').count()
    checks['track_cards'] = page.locator('#trackCards .track-card').count()
    checks['has_mode_marker'] = 'Mesh9.6' in page.locator('body').inner_text()
    checks['initial_student'] = page.locator('#studentTitle').inner_text()

    # Storage fallback and recomputation
    page.click('#saveState')
    checks['save_fallback'] = '已保存到本机浏览器' in page.locator('#toast').inner_text()
    page.click('#recompute')
    page.wait_for_timeout(120)
    checks['recompute'] = page.locator('#portfolioSummary .portfolio-block').count() == 3

    # Pipeline interaction
    page.click('[data-view="pipeline"]')
    page.fill('#a_company', '浏览器验收公司')
    page.fill('#a_role', 'AI业务运营校招生')
    page.select_option('#a_track', 'private_ai_ops')
    page.select_option('#a_status', 'applied')
    page.fill('#a_deadline', '2026-09-28')
    page.fill('#a_source', '企业官网（QA合成）')
    page.fill('#a_resume', 'AI运营版 QA')
    page.select_option('#a_match', '0.9')
    page.fill('#a_note', '仅用于浏览器验收')
    page.click('#addApplication')
    page.wait_for_timeout(180)
    checks['pipeline_added'] = '浏览器验收公司' in page.locator('#applicationsTable').inner_text()

    # JD matcher
    page.click('[data-view="matcher"]')
    page.fill('#jdText', '岗位要求Excel、SQL、数据分析、项目管理、AI工作流和跨部门沟通能力。')
    page.fill('#resumeText', '负责校园运营项目，使用Excel完成数据分析，搭建AI工作流，协调3个部门，活动转化率提升12%，连续交付6周。')
    page.click('#runMatcher')
    page.wait_for_timeout(150)
    match_text = page.locator('#matchResults').inner_text()
    checks['matcher_rendered'] = 'JD关键词覆盖' in match_text and 'SQL' in match_text

    # Evidence interaction
    page.click('[data-view="evidence"]')
    page.fill('#e_title', 'QA真实问题作品')
    page.select_option('#e_type', '项目作品')
    page.select_option('#e_status', 'stakeholder')
    page.fill('#e_date', '2026-09-02')
    page.fill('#e_source', '浏览器验收')
    page.fill('#e_claim', '完成一个可核验的流程改进原型')
    page.fill('#e_metric', '仅为QA合成记录')
    page.click('#addEvidence')
    page.wait_for_timeout(150)
    checks['evidence_added'] = 'QA真实问题作品' in page.locator('#evidenceTable').inner_text()

    # Risk scan
    page.click('[data-view="safety"]')
    page.fill('#riskText', '入职前先办理培训贷，再把短信验证码发给老师，保证录用。')
    page.click('#scanRisk')
    page.wait_for_timeout(150)
    risk_text = page.locator('#riskResults').inner_text()
    checks['risk_scanner'] = 'CRITICAL' in risk_text and '培训' in risk_text

    # Offer comparison
    page.click('[data-view="offers"]')
    page.fill('#o_name', 'QA合成Offer')
    page.fill('#o_role', '供应链运营')
    page.select_option('#o_track', 'industrial_ops')
    page.fill('#o_salary', '8500')
    page.fill('#o_months', '13')
    page.fill('#o_bonus', '5000')
    page.fill('#o_housing', '500')
    page.fill('#o_cost', '4200')
    page.fill('#o_hours', '48')
    page.fill('#o_commute', '45')
    page.click('#addOffer')
    page.wait_for_timeout(150)
    checks['offer_added'] = 'QA合成Offer' in page.locator('#offerCards').inner_text()

    # Calendar and official-source discipline
    page.click('[data-view="calendar"]')
    source_text = page.locator('#officialSources').inner_text()
    checks['official_source_register'] = '等待正式公告' in source_text and '2027全国硕士研究生招生考试' in source_text
    checks['decision_gates'] = page.locator('#decisionGates .gate').count()

    # Plan/export view
    page.click('[data-view="export"]')
    plan_text = page.locator('#planPreview').inner_text()
    checks['plan_preview'] = '2027就业行动方案' in plan_text and '路径组合' in plan_text and '不得伪造' in plan_text

    # Return to dashboard and capture final screenshot
    page.click('[data-view="dashboard"]')
    page.wait_for_timeout(250)
    page.screenshot(path=str(ASSETS / 'client_dashboard.png'), full_page=True)

    # Mobile navigation and responsive layout
    mobile = context.new_page()
    mobile.set_viewport_size({'width': 390, 'height': 844})
    mobile.on('console', lambda msg: console_errors.append('mobile: ' + msg.text) if msg.type == 'error' else None)
    mobile.on('pageerror', lambda err: page_errors.append('mobile: ' + str(err)))
    mobile.on('request', lambda req: requests.append(req.url))
    mobile.set_content(html, wait_until='load')
    mobile.wait_for_timeout(300)
    mobile.click('#mobileMenu')
    checks['mobile_menu'] = 'open' in (mobile.locator('#sidebar').get_attribute('class') or '')
    mobile.click('[data-view="safety"]')
    checks['mobile_navigation'] = mobile.locator('#safety.view.active').count() == 1
    mobile.wait_for_timeout(350)
    checks['mobile_no_horizontal_overflow'] = mobile.evaluate('document.documentElement.scrollWidth <= document.documentElement.clientWidth + 1')
    mobile.screenshot(path=str(ASSETS / 'client_mobile.png'), full_page=True)
    mobile.close()
    browser.close()

boolean_checks = [v for k,v in checks.items() if isinstance(v, bool)]
status = (
    'PASS' if all(boolean_checks)
    and checks.get('metric_cards') == 5
    and checks.get('track_cards') == 12
    and checks.get('decision_gates') == 6
    and not console_errors and not page_errors and not requests
    else 'FAIL'
)
result = {
    'system': 'DIKWP CAREER RUDDER / ZHIDUO 17.0.0',
    'artifact': str(HTML),
    'status': status,
    'checks': checks,
    'console_errors': console_errors,
    'page_errors': page_errors,
    'network_requests_observed': requests,
    'network_policy': 'The standalone build executed from in-memory HTML and initiated zero network requests.',
    'screenshot': str(ASSETS / 'client_dashboard.png')
}
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
if status != 'PASS':
    raise SystemExit(1)
