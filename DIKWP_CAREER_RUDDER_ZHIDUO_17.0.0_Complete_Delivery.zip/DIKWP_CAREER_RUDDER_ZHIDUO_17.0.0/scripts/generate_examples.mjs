import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
const require = createRequire(import.meta.url);
const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const C = require(path.join(root, 'app', 'core.js'));

const profile = JSON.parse(fs.readFileSync(path.join(root, 'examples', 'business_admin_2027.json'), 'utf8'));
const applications = [
  { id:'sample-app-1', company:'合成制造企业', role:'供应链运营校招生', trackId:'industrial_ops', status:'applied', deadline:'2026-09-20', source:'演示来源', resume:'供应链版 v1', match:.8, note:'补充库存改善案例；不是现实岗位' },
  { id:'sample-app-2', company:'合成数字化服务企业', role:'AI业务运营', trackId:'private_ai_ops', status:'interview1', deadline:'2026-09-18', source:'演示来源', resume:'AI运营版 v2', match:.85, note:'准备人机分工和验证案例；不是现实岗位' }
];
const evidence = [
  { id:'sample-evidence-1', title:'校园活动运营复盘', type:'项目作品', status:'self', date:'2026-06-20', source:'演示本地文件', claim:'完成基础活动策划与复盘', metric:'参与者48人；数字为合成演示', prev:'GENESIS', hash:'sample0001' },
  { id:'sample-evidence-2', title:'流程整理实习反馈', type:'实习成果', status:'stakeholder', date:'2026-08-10', source:'演示主管反馈', claim:'能够按时整理流程和周报', metric:'连续6周按期交付；合成演示', prev:'sample0001', hash:'sample0002' }
];
const state = {
  profile,
  worlds:C.clone(C.WORLD_MODELS),
  applications,
  evidence,
  deadlines:[
    { id:'sample-gate-1', title:'完成首批20个高匹配岗位池', date:'2026-09-10', type:'企业招聘', status:'planning', source:'个人行动门' },
    { id:'sample-gate-2', title:'秋招第一轮复盘', date:'2026-10-15', type:'学校事项', status:'planning', source:'职舵规划窗口' }
  ],
  offers:[]
};
const plan = C.makeCareerPlan(state, new Date('2026-09-02T08:00:00+08:00'));
fs.writeFileSync(path.join(root, 'examples', 'business_admin_2027_plan.json'), JSON.stringify(plan, null, 2));
fs.writeFileSync(path.join(root, 'release', 'zhiduo-business-admin-2027-plan-demo.json'), JSON.stringify(plan, null, 2));
console.log(JSON.stringify({main:plan.portfolio.main.trackName, hedge:plan.portfolio.hedge.trackName, allocations:plan.portfolio.allocations}, null, 2));
