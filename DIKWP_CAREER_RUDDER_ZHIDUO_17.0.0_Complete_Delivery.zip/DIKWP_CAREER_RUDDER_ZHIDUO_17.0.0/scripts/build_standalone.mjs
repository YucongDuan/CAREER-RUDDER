import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const indexPath = path.join(root, 'index.html');
const cssPath = path.join(root, 'app', 'styles.css');
const corePath = path.join(root, 'app', 'core.js');
const appPath = path.join(root, 'app', 'app.js');
const releaseDir = path.join(root, 'release');
const outPath = path.join(releaseDir, 'ZHIDUO_2027_Client_17.0.0.html');

function read(p) { return fs.readFileSync(p, 'utf8'); }
function escapeScript(s) { return s.replace(/<\/script/gi, '<\\/script'); }

let html = read(indexPath);
const css = read(cssPath);
const core = escapeScript(read(corePath));
const app = escapeScript(read(appPath));

html = html.replace('<link rel="stylesheet" href="app/styles.css">', () => `<style>\n${css}\n</style>`);
html = html.replace('<script src="app/core.js"></script>', () => `<script>\n${core}\n</script>`);
html = html.replace('<script src="app/app.js"></script>', () => `<script>\n${app}\n</script>`);
html = html.replace('</head>', '  <meta name="generator" content="DIKWP CAREER RUDDER / ZHIDUO 17.0.0 standalone builder">\n</head>');

if (/\b(?:src|href)=["'](?:app\/|\.\/)/.test(html)) {
  throw new Error('Standalone build still contains local runtime dependencies.');
}
if (!html.includes('ZHIDUO17_CHINA2027')) {
  throw new Error('Core mode marker missing from standalone build.');
}
fs.mkdirSync(releaseDir, { recursive: true });
fs.writeFileSync(outPath, html, 'utf8');
console.log(JSON.stringify({ output: outPath, bytes: fs.statSync(outPath).size }, null, 2));
