#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(__file__).resolve().parents[1]
RELEASE = ROOT / 'release'
RELEASE.mkdir(parents=True, exist_ok=True)


def run(cmd: list[str]) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True)
    if cp.returncode:
        sys.stderr.write(cp.stdout)
        sys.stderr.write(cp.stderr)
        raise RuntimeError(f"command failed: {' '.join(cmd)}")
    return cp


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


started = datetime.now(timezone.utc)
results: dict[str, object] = {}
failures: list[str] = []

# Rebuild all deterministic browser artifacts.
build = run(['node', 'scripts/build_standalone.mjs'])
examples = run(['node', 'scripts/generate_examples.mjs'])
run(['node', '--check', 'app/core.js'])
run(['node', '--check', 'app/app.js'])
run(['node', '--check', 'scripts/build_standalone.mjs'])
results['javascript_syntax'] = 'PASS'

# Unit and behavioral tests.
test_cp = run(['node', '--test', 'tests/test_core.mjs'])
test_text = test_cp.stdout + test_cp.stderr
(RELEASE / 'TEST_REPORT.txt').write_text(test_text, encoding='utf-8')
match = re.search(r'# tests (\d+)', test_text)
passed = re.search(r'# pass (\d+)', test_text)
failed = re.search(r'# fail (\d+)', test_text)
results['tests'] = {
    'total': int(match.group(1)) if match else None,
    'passed': int(passed.group(1)) if passed else None,
    'failed': int(failed.group(1)) if failed else None,
    'status': 'PASS' if failed and int(failed.group(1)) == 0 else 'FAIL'
}
if results['tests']['status'] != 'PASS':
    failures.append('unit tests')

# Parse every JSON document in the project, excluding future archive validation.
json_files = [p for p in ROOT.rglob('*.json') if p.is_file()]
json_objects: dict[Path, object] = {}
for p in json_files:
    try:
        json_objects[p] = json.loads(p.read_text(encoding='utf-8'))
    except Exception as exc:
        failures.append(f'json parse: {p.relative_to(ROOT)}: {exc}')
results['json_parse'] = {'files': len(json_files), 'status': 'PASS' if not any(x.startswith('json parse') for x in failures) else 'FAIL'}

# JSON Schema validation for all public object types.
format_checker = FormatChecker()
def validate(schema_name: str, instance_name: str) -> list[str]:
    schema = json.loads((ROOT / 'schemas' / schema_name).read_text(encoding='utf-8'))
    instance = json.loads((ROOT / instance_name).read_text(encoding='utf-8'))
    validator = Draft202012Validator(schema, format_checker=format_checker)
    return [e.message for e in sorted(validator.iter_errors(instance), key=lambda e: list(e.path))]

schema_cases = [
    ('student-profile.v1.schema.json', 'examples/business_admin_2027.json'),
    ('student-profile.v1.schema.json', 'examples/cs_2027.json'),
    ('application.v1.schema.json', 'examples/application_demo.json'),
    ('evidence.v1.schema.json', 'examples/evidence_demo.json'),
    ('offer.v1.schema.json', 'examples/offer_demo.json'),
    ('career-plan.v1.schema.json', 'examples/business_admin_2027_plan.json'),
]
schema_errors: dict[str, list[str]] = {}
for schema_name, instance_name in schema_cases:
    errors = validate(schema_name, instance_name)
    if errors:
        schema_errors[f'{schema_name}::{instance_name}'] = errors
if schema_errors:
    failures.append('schema validation')
results['schema_validation'] = {'cases': len(schema_cases), 'status': 'FAIL' if schema_errors else 'PASS', 'errors': schema_errors}

# Standalone integrity and UI contract.
standalone = RELEASE / 'ZHIDUO_2027_Client_17.0.0.html'
standalone_text = standalone.read_text(encoding='utf-8')
required_ids = [
    'dashboard','profile','tracks','pipeline','matcher','evidence','calendar','offers','safety','export',
    'dashboardMetrics','trackCards','applicationsTable','matchResults','evidenceTable','officialSources','offerCards','riskResults','planPreview'
]
missing_ids = [x for x in required_ids if f'id="{x}"' not in standalone_text]
external_dependency_patterns = {
    'external_script': r'<script\b[^>]*\bsrc\s*=',
    'external_stylesheet': r'<link\b[^>]*rel=["\']stylesheet["\'][^>]*>',
    'css_import': r'@import\s+',
    'remote_css_url': r'url\(\s*["\']?https?://',
    'iframe': r'<iframe\b',
}
standalone_hits = {name: bool(re.search(pat, standalone_text, flags=re.I)) for name, pat in external_dependency_patterns.items()}
if missing_ids or any(standalone_hits.values()):
    failures.append('standalone integrity')
results['standalone'] = {
    'bytes': standalone.stat().st_size,
    'required_ids': len(required_ids),
    'missing_ids': missing_ids,
    'external_dependency_hits': standalone_hits,
    'status': 'PASS' if not missing_ids and not any(standalone_hits.values()) else 'FAIL'
}

# Static scan only on executable client code. Links in source register are permitted;
# active network clients, dynamic execution and process-launch primitives are not.
runtime_files = [ROOT / 'app' / 'core.js', ROOT / 'app' / 'app.js']
forbidden = {
    'fetch_call': r'\bfetch\s*\(',
    'xml_http_request': r'\bXMLHttpRequest\b',
    'websocket': r'\bWebSocket\b',
    'send_beacon': r'\bsendBeacon\s*\(',
    'eval_call': r'\beval\s*\(',
    'function_constructor': r'\bnew\s+Function\s*\(',
    'dynamic_import': r'\bimport\s*\(',
    'service_worker': r'\bserviceWorker\b',
    'child_process': r'\bchild_process\b',
}
static_findings: list[dict[str, object]] = []
for p in runtime_files:
    text = p.read_text(encoding='utf-8')
    for name, pattern in forbidden.items():
        for m in re.finditer(pattern, text):
            line = text.count('\n', 0, m.start()) + 1
            static_findings.append({'file': str(p.relative_to(ROOT)), 'rule': name, 'line': line, 'match': m.group(0)})
static_scan = {
    'runtime_files': [str(p.relative_to(ROOT)) for p in runtime_files],
    'rules': list(forbidden),
    'findings': static_findings,
    'status': 'PASS' if not static_findings else 'FAIL'
}
(RELEASE / 'STATIC_SCAN.json').write_text(json.dumps(static_scan, ensure_ascii=False, indent=2), encoding='utf-8')
results['static_scan'] = static_scan
if static_findings:
    failures.append('static scan')

# Browser functional, network and mobile QA.
browser_cp = run([sys.executable, 'scripts/browser_qa.py'])
browser_result = json.loads((RELEASE / 'BROWSER_QA.json').read_text(encoding='utf-8'))
results['browser_qa'] = browser_result
if browser_result.get('status') != 'PASS':
    failures.append('browser QA')

# Invariants in exported plan.
plan = json.loads((ROOT / 'examples' / 'business_admin_2027_plan.json').read_text(encoding='utf-8'))
invariants = plan.get('invariants', {})
expected_invariants = {
    'automatedHumanWorthRanking': 0,
    'automatedHiringDecision': 0,
    'fakeExperienceGeneration': 0,
    'externalAutomaticApplication': 0,
    'externalAutomaticValueTransfer': 0,
    'userRevocationPrecedence': 1,
    'scenarioWeightsAreForecastProbabilities': 0,
}
invariant_errors = {k: {'expected': v, 'actual': invariants.get(k)} for k, v in expected_invariants.items() if invariants.get(k) != v}
alloc_total = sum(a.get('share', 0) for a in plan.get('portfolio', {}).get('allocations', []))
if invariant_errors or alloc_total != 100:
    failures.append('decision invariants')
results['decision_invariants'] = {
    'expected': expected_invariants,
    'mismatches': invariant_errors,
    'allocation_total': alloc_total,
    'status': 'PASS' if not invariant_errors and alloc_total == 100 else 'FAIL'
}

# Basic accessibility contract.
source_html = (ROOT / 'index.html').read_text(encoding='utf-8')
a11y = {
    'html_lang_zh_cn': 'lang="zh-CN"' in source_html,
    'viewport_meta': 'name="viewport"' in source_html,
    'main_nav_label': 'aria-label="主导航"' in source_html,
    'live_status': 'aria-live="polite"' in source_html,
    'label_wiring_runtime': 'label.htmlFor = control.id' in (ROOT / 'app' / 'app.js').read_text(encoding='utf-8'),
}
results['accessibility_contract'] = {'checks': a11y, 'status': 'PASS' if all(a11y.values()) else 'FAIL'}
if not all(a11y.values()):
    failures.append('accessibility contract')

# Software bill of materials: dependency-free browser client.
sbom = {
    'spdxVersion': 'SPDX-2.3',
    'dataLicense': 'CC0-1.0',
    'SPDXID': 'SPDXRef-DOCUMENT',
    'name': 'DIKWP-CAREER-RUDDER-ZHIDUO-17.0.0-SBOM',
    'documentNamespace': 'https://dikwp.example/spdx/zhiduo-17.0.0',
    'creationInfo': {'created': datetime.now(timezone.utc).isoformat(), 'creators': ['Tool: internal-release-validator']},
    'packages': [{
        'name': 'dikwp-career-rudder-zhiduo', 'SPDXID': 'SPDXRef-Package', 'versionInfo': '17.0.0',
        'downloadLocation': 'NOASSERTION', 'filesAnalyzed': False, 'licenseConcluded': 'Apache-2.0',
        'licenseDeclared': 'Apache-2.0', 'copyrightText': 'NOASSERTION',
        'externalRefs': [], 'comment': 'Dependency-free browser application. Python and Node are development/validation tools only.'
    }],
    'relationships': [{'spdxElementId': 'SPDXRef-DOCUMENT', 'relationshipType': 'DESCRIBES', 'relatedSpdxElement': 'SPDXRef-Package'}]
}
(RELEASE / 'SBOM.spdx.json').write_text(json.dumps(sbom, ensure_ascii=False, indent=2), encoding='utf-8')
results['sbom'] = 'PASS'

finished = datetime.now(timezone.utc)
summary = {
    'system': 'DIKWP CAREER RUDDER / ZHIDUO 17.0.0',
    'mode': 'ZHIDUO17_CHINA2027_GRADUATE_MULTI_WORLD_TRACK_PORTFOLIO_EVIDENCE_PIPELINE_OFFER_REALITY_CLOSURE',
    'data_as_of': '2026-09-02',
    'started_utc': started.isoformat(),
    'finished_utc': finished.isoformat(),
    'status': 'PASS' if not failures else 'FAIL',
    'failures': failures,
    'results': results,
    'principal_artifacts': {
        'standalone_html': {'path': 'release/ZHIDUO_2027_Client_17.0.0.html', 'sha256': sha256(standalone), 'bytes': standalone.stat().st_size},
        'sample_plan': {'path': 'release/zhiduo-business-admin-2027-plan-demo.json', 'sha256': sha256(RELEASE / 'zhiduo-business-admin-2027-plan-demo.json')},
        'desktop_screenshot': {'path': 'assets/client_dashboard.png', 'sha256': sha256(ROOT / 'assets' / 'client_dashboard.png')},
        'mobile_screenshot': {'path': 'assets/client_mobile.png', 'sha256': sha256(ROOT / 'assets' / 'client_mobile.png')},
    },
    'claim_boundary': 'PASS validates deterministic code paths and synthetic examples only. It does not establish employment, admission, salary, exam, or real-world career outcome accuracy.'
}
(RELEASE / 'VALIDATION_RECEIPT.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')

build_summary = {
    'version': '17.0.0',
    'source_files': len([p for p in ROOT.rglob('*') if p.is_file() and 'release' not in p.parts]),
    'json_files_parsed': results['json_parse']['files'],
    'schema_cases': len(schema_cases),
    'unit_tests': results['tests'],
    'browser_qa': browser_result['status'],
    'desktop_screenshot': 'assets/client_dashboard.png',
    'mobile_screenshot': 'assets/client_mobile.png',
    'standalone_bytes': standalone.stat().st_size,
    'status': summary['status']
}
(RELEASE / 'BUILD_SUMMARY.json').write_text(json.dumps(build_summary, ensure_ascii=False, indent=2), encoding='utf-8')

print(json.dumps(summary, ensure_ascii=False, indent=2))
if failures:
    raise SystemExit(1)
