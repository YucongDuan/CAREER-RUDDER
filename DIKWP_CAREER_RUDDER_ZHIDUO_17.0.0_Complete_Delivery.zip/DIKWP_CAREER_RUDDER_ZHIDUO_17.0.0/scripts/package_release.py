#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RELEASE = ROOT / 'release'
PREFIX = 'DIKWP_CAREER_RUDDER_ZHIDUO_17.0.0'
SOURCE_ZIP = RELEASE / f'{PREFIX}_source.zip'
COMPLETE_ZIP = RELEASE / f'{PREFIX}_Complete_Delivery.zip'
ROOT_IN_ZIP = PREFIX


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def ignored(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    return any(part in {'__pycache__', '.git', 'node_modules'} for part in rel.parts) or path.suffix == '.pyc'


def zip_paths(out: Path, paths: list[Path]) -> int:
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists(): out.unlink()
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(paths):
            arc = str(Path(ROOT_IN_ZIP) / p.relative_to(ROOT))
            z.write(p, arc)
    with zipfile.ZipFile(out) as z:
        bad = z.testzip()
        if bad:
            raise RuntimeError(f'corrupt archive entry: {bad}')
        return len(z.infolist())

# Always package a newly validated build.
subprocess.run([sys.executable, 'scripts/validate_release.py'], cwd=ROOT, check=True)

# Remove previous package metadata to avoid accidental recursion.
for p in [SOURCE_ZIP, COMPLETE_ZIP, RELEASE/'SHA256SUMS.txt', RELEASE/'COMPLETE_DELIVERY_SHA256.txt', RELEASE/'ARCHIVE_VALIDATION.json', RELEASE/'FILE_MANIFEST_SHA256.txt']:
    if p.exists(): p.unlink()

source_paths = [p for p in ROOT.rglob('*') if p.is_file() and not ignored(p) and 'release' not in p.relative_to(ROOT).parts and 'outputs' not in p.relative_to(ROOT).parts]
source_count = zip_paths(SOURCE_ZIP, source_paths)

# Rebuild and retest from the source archive in an isolated directory.
with tempfile.TemporaryDirectory(prefix='zhiduo-source-qa-') as td:
    td_path = Path(td)
    with zipfile.ZipFile(SOURCE_ZIP) as z:
        z.extractall(td_path)
    extracted = td_path / ROOT_IN_ZIP
    test_cp = subprocess.run(['node', '--test', 'tests/test_core.mjs'], cwd=extracted, text=True, capture_output=True)
    build_cp = subprocess.run(['node', 'scripts/build_standalone.mjs'], cwd=extracted, text=True, capture_output=True)
    source_retest = {
        'node_test_returncode': test_cp.returncode,
        'standalone_build_returncode': build_cp.returncode,
        'tests_pass_marker': '# fail 0' in test_cp.stdout,
        'standalone_exists': (extracted/'release'/'ZHIDUO_2027_Client_17.0.0.html').exists(),
    }
    if test_cp.returncode or build_cp.returncode or not source_retest['standalone_exists']:
        sys.stderr.write(test_cp.stdout + test_cp.stderr + build_cp.stdout + build_cp.stderr)
        raise RuntimeError('source archive re-test failed')

# Candidate contents for the complete archive. Checksums of individual files are
# written before the complete archive; the archive's own hash remains external.
def complete_candidates() -> list[Path]:
    result = []
    for p in ROOT.rglob('*'):
        if not p.is_file() or ignored(p):
            continue
        if p in {COMPLETE_ZIP, RELEASE/'SHA256SUMS.txt', RELEASE/'COMPLETE_DELIVERY_SHA256.txt'}:
            continue
        if 'outputs' in p.relative_to(ROOT).parts:
            continue
        result.append(p)
    return result

# First write archive-validation metadata and then a manifest for all payload files.
# The reported complete entry count includes the manifest itself.
pre_candidates = complete_candidates()
archive_validation = {
    'system': 'DIKWP CAREER RUDDER / ZHIDUO 17.0.0',
    'generated_utc': datetime.now(timezone.utc).isoformat(),
    'source_archive': {
        'file': SOURCE_ZIP.name,
        'entries': source_count,
        'zip_integrity': 'PASS',
        'isolated_rebuild_and_tests': source_retest,
    },
    'complete_archive': {
        'file': COMPLETE_ZIP.name,
        'expected_entries': len(pre_candidates) + 2,  # this JSON + manifest
        'zip_integrity': 'PASS if packaging completes',
    },
    'status': 'PASS if this file is present in a successfully returned release'
}
(RELEASE/'ARCHIVE_VALIDATION.json').write_text(json.dumps(archive_validation, ensure_ascii=False, indent=2), encoding='utf-8')

manifest_paths = [p for p in complete_candidates() if p.name != 'FILE_MANIFEST_SHA256.txt']
manifest_lines = [f'{sha256(p)}  {p.relative_to(ROOT).as_posix()}' for p in sorted(manifest_paths)]
(RELEASE/'FILE_MANIFEST_SHA256.txt').write_text('\n'.join(manifest_lines) + '\n', encoding='utf-8')

complete_count = zip_paths(COMPLETE_ZIP, complete_candidates())
if complete_count != archive_validation['complete_archive']['expected_entries']:
    raise RuntimeError(f"complete archive entry count mismatch: {complete_count} != {archive_validation['complete_archive']['expected_entries']}")

complete_hash = sha256(COMPLETE_ZIP)
(RELEASE/'COMPLETE_DELIVERY_SHA256.txt').write_text(f'{complete_hash}  {COMPLETE_ZIP.name}\n', encoding='utf-8')

main_artifacts = [
    COMPLETE_ZIP,
    SOURCE_ZIP,
    RELEASE/'ZHIDUO_2027_Client_17.0.0.html',
    RELEASE/'zhiduo-business-admin-2027-plan-demo.json',
    RELEASE/'VALIDATION_RECEIPT.json',
    RELEASE/'TEST_REPORT.txt',
    RELEASE/'BROWSER_QA.json',
    RELEASE/'STATIC_SCAN.json',
    RELEASE/'SBOM.spdx.json',
    ROOT/'assets'/'client_dashboard.png',
    ROOT/'assets'/'client_mobile.png',
]
(RELEASE/'SHA256SUMS.txt').write_text('\n'.join(f'{sha256(p)}  {p.relative_to(ROOT).as_posix()}' for p in main_artifacts) + '\n', encoding='utf-8')

# Final independent integrity check.
with zipfile.ZipFile(COMPLETE_ZIP) as z:
    complete_bad = z.testzip()
with zipfile.ZipFile(SOURCE_ZIP) as z:
    source_bad = z.testzip()
if complete_bad or source_bad:
    raise RuntimeError(f'archive integrity failure: source={source_bad}, complete={complete_bad}')

result = {
    'status': 'PASS',
    'source_zip': {'path': str(SOURCE_ZIP), 'entries': source_count, 'bytes': SOURCE_ZIP.stat().st_size, 'sha256': sha256(SOURCE_ZIP)},
    'complete_zip': {'path': str(COMPLETE_ZIP), 'entries': complete_count, 'bytes': COMPLETE_ZIP.stat().st_size, 'sha256': complete_hash},
    'standalone': {'path': str(RELEASE/'ZHIDUO_2027_Client_17.0.0.html'), 'bytes': (RELEASE/'ZHIDUO_2027_Client_17.0.0.html').stat().st_size, 'sha256': sha256(RELEASE/'ZHIDUO_2027_Client_17.0.0.html')},
    'source_retest': source_retest,
}
print(json.dumps(result, ensure_ascii=False, indent=2))
