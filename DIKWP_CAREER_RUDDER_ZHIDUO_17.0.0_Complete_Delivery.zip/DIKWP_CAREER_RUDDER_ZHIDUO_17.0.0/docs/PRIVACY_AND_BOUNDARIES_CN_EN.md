# Privacy, safety and claim boundaries / 隐私、安全与主张边界

Hard invariants:

```text
AUTOMATED_HUMAN_WORTH_RANKING = 0
AUTOMATED_HIRING_OR_ADMISSION_DECISION = 0
FAKE_EXPERIENCE_GENERATION = 0
EXTERNAL_AUTOMATIC_APPLICATION = 0
EXTERNAL_AUTOMATIC_VALUE_TRANSFER = 0
USER_REVOCATION_PRECEDENCE = 1
SCENARIO_WEIGHTS_ARE_CALIBRATED_PROBABILITIES = 0
```

The client does not upload data and does not contact employers. Official links open only after a user click. LocalStorage is not an encrypted vault; export, redact and protect files accordingly.

The recruitment-risk scanner detects phrases, not legal facts. A warning requires verification through official employer, school and public-service channels.
