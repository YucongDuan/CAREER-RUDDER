# Official source register

Verified or reviewed on 2026-09-02.

1. National College Student Employment Service Platform: https://www.ncss.cn/
2. State-owned Assets Supervision and Administration Commission recruitment: https://www.sasac.gov.cn/n2588035/n2588325/n2588350/index.html
3. China Graduate Admissions Information Network: https://yz.chsi.com.cn/
4. National Civil Service Administration: https://www.scs.gov.cn/
5. Ministry of Human Resources and Social Security: https://www.mohrss.gov.cn/
6. Ministry of Education job-search risk reminder: https://www.moe.gov.cn/jyb_xwfb/gzdt_gzdt/s5987/202405/t20240521_1131747.html

Evidence boundary: employer-specific posts prove that some 2027 recruitment has started; they do not prove that every employer has opened. The absence of a 2027 national examination schedule from the reviewed official pages is handled as “await official notice”, not as a prediction of exact dates.
