# Decision model / 决策模型

The system evaluates the complete student-path configuration rather than treating a degree, examination or employer label as a permanent guarantee.

For track p and world w:

```text
Score(p,w) = 0.40 world viability
           + 0.24 skill fit
           + 0.12 major fit
           + 0.10 evidence readiness
           + 0.08 preference/constraint fit
           + 0.06 phase urgency
           - constraint penalty
```

Outputs retain expected viability, worst-world viability, option value, evidence readiness and lock-in cost separately. The advisory index is used for navigation only; it has no authority to rank human worth or make hiring/admission decisions.

The portfolio has three parts:

1. primary track;
2. heterogeneous hedge with a different failure structure;
3. common proof base: portfolio, applications, AI-assisted verification and third-party evidence.

Hard gates prevent a vague postgraduate path, low-fit civil-service path, underfunded high-debt venture, or long-income-delay path from silently becoming the primary route.
