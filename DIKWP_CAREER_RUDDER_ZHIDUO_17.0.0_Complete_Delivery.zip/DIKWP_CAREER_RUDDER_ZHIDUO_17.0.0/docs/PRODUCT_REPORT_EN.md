# DIKWP CAREER RUDDER / ZHIDUO 17.0.0 — Product and Implementation Report

## Purpose

ZHIDUO is a local-first career-planning and employment-decision client for students graduating in China in 2027. It brings enterprise recruitment, state-owned employers, civil-service and public-institution examinations, targeted postgraduate study, grassroots programmes, internships, evidence portfolios, job-description matching, offer comparison and recruitment-risk screening into one revisable workflow.

It is not a personality test, an automated applicant, or an employment predictor. It treats career entry as a constrained portfolio problem under multiple non-isomorphic futures.

## Decision structure

```text
Evidence and source status
→ student purpose and non-negotiable floors
→ six future worlds
→ twelve career tracks
→ admissibility gates
→ primary track + heterogeneous hedge + common proof base
→ applications, projects and examination actions
→ receipts and third-party evidence
→ dated decision gates
→ continue, intensify, pivot or stop
→ reality-contact revision
```

The client retains expected viability, worst-world viability, evidence readiness, option value and lock-in cost as separate dimensions. A navigation index is displayed, but it has no authority to rank human worth or make hiring or admission decisions.

## Major capabilities

- editable student constraints and eleven skill dimensions;
- twelve career tracks evaluated across six future worlds;
- application pipeline and funnel diagnostics;
- evidence-based CV–JD matching without fabrication;
- append-oriented evidence ledger;
- official-source register separating official notices from planning windows;
- multi-dimensional offer comparison with a Pareto frontier;
- recruitment-risk phrase scanner;
- local JSON, CSV and printable-plan export;
- complete offline operation without an account, database or model API.

## Hard boundaries

```text
AUTOMATED_HUMAN_WORTH_RANKING = 0
AUTOMATED_HIRING_OR_ADMISSION_DECISION = 0
FAKE_EXPERIENCE_GENERATION = 0
EXTERNAL_AUTOMATIC_APPLICATION = 0
EXTERNAL_AUTOMATIC_VALUE_TRANSFER = 0
USER_REVOCATION_PRECEDENCE = 1
SCENARIO_WEIGHTS_ARE_CALIBRATED_PROBABILITIES = 0
```

All supplied jobs, offers and outcome records are synthetic demonstrations. Successful software validation does not establish real-world employment, admission, salary or career-outcome accuracy.
