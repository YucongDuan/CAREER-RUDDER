import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const C = require('../app/core.js');

const DATE = new Date('2026-09-02T00:00:00Z');
const profile = C.clone(C.DEFAULT_PROFILE);
const state = { profile, worlds: C.clone(C.WORLD_MODELS), applications: [], evidence: [], deadlines: [], offers: [] };

function track(id){ return C.TRACKS.find(t=>t.id===id); }

test('version and mode are fixed', () => {
  assert.equal(C.VERSION, '17.0.0');
  assert.match(C.MODE, /^ZHIDUO17_/);
  assert.equal(C.DATA_AS_OF, '2026-09-02');
});

test('catalog exposes 11 skills and 12 tracks', () => {
  assert.equal(C.SKILLS.length, 11);
  assert.equal(C.TRACKS.length, 12);
  assert.equal(new Set(C.TRACKS.map(t=>t.id)).size, 12);
});

test('world-model weights normalize to one', () => {
  const rows = C.normalizeWorlds(C.WORLD_MODELS);
  assert.ok(Math.abs(C.sum(rows.map(w=>w.weight)) - 1) < 1e-5);
  assert.ok(rows.every(w=>w.weight>=0 && w.weight<=1));
});

test('zero world weights fall back without NaN', () => {
  const rows = C.normalizeWorlds([{id:'a',weight:0},{id:'b',weight:0}]);
  assert.ok(rows.every(w=>Number.isFinite(w.weight)));
  assert.ok(Math.abs(C.sum(rows.map(w=>w.weight)) - 1) < 1e-12);
  assert.equal(rows[0].weight, .5);
});

test('September 2026 is autumn main campaign', () => {
  const p = C.phaseFor(DATE, '2027-06-30');
  assert.equal(p.id, 'autumn_main');
  assert.ok(p.daysToGrad > 250);
});

test('phase changes after graduation', () => {
  assert.equal(C.phaseFor(new Date('2027-07-05T00:00:00Z'), '2027-06-30').id, 'post_graduation');
});

test('evidence readiness rises with verified evidence', () => {
  const low = C.evidenceReadiness(profile, { evidenceCount: 0 });
  const highP = C.clone(profile);
  highP.skills.proof = .9;
  highP.evidenceCounts = { internships:2, projects:3, externalVerifications:3, quantifiedStories:5 };
  const high = C.evidenceReadiness(highP, { evidenceCount: 8 });
  assert.ok(high > low);
  assert.ok(high <= 1);
});

test('track evaluation stays in bounded interval', () => {
  for (const t of C.TRACKS) {
    const e = C.evaluateTrack(profile, t, C.WORLD_MODELS, {}, DATE);
    for (const k of ['skillFit','majorFit','readiness','preferenceFit','urgency','expected','worst','optionValue','lockIn','advisoryIndex']) {
      assert.ok(e[k] >= 0 && e[k] <= 1, `${t.id}.${k}`);
    }
    assert.equal(Object.keys(e.worldScores).length, C.WORLD_MODELS.length);
  }
});

test('vague postgraduate path is blocked from main path', () => {
  const p = C.clone(profile); p.postgraduateSpecificity = .20;
  const e = C.evaluateTrack(p, track('postgraduate'), C.WORLD_MODELS, {}, DATE);
  assert.equal(e.mainAdmissible, false);
  assert.ok(e.blockers.some(x=>x.includes('具体')));
});

test('specific postgraduate path may become admissible', () => {
  const p = C.clone(profile); p.postgraduateSpecificity = .80; p.runwayMonths = 18; p.researchCommitment = .9;
  const e = C.evaluateTrack(p, track('postgraduate'), C.WORLD_MODELS, {}, DATE);
  assert.equal(e.mainAdmissible, true);
});

test('low public-service fit blocks civil service as main path', () => {
  const p = C.clone(profile); p.publicServiceFit = .20;
  const e = C.evaluateTrack(p, track('civil_service'), C.WORLD_MODELS, {}, DATE);
  assert.equal(e.mainAdmissible, false);
});

test('underfunded venture path is blocked', () => {
  const p = C.clone(profile); p.runwayMonths = 2; p.ventureEvidence = 0;
  const e = C.evaluateTrack(p, track('microventure'), C.WORLD_MODELS, {}, DATE);
  assert.equal(e.mainAdmissible, false);
});

test('portfolio always sums to 100 and includes heterogeneous hedge', () => {
  const p = C.recommendPortfolio(profile, C.WORLD_MODELS, {}, DATE);
  assert.equal(C.sum(p.allocations.map(a=>a.share)), 100);
  assert.notEqual(p.main.trackId, p.hedge.trackId);
  assert.equal(p.allocations[2].id, 'common_proof');
});

test('default business student does not main vague postgraduate or venture', () => {
  const p = C.recommendPortfolio(profile, C.WORLD_MODELS, {}, DATE);
  assert.notEqual(p.main.trackId, 'postgraduate');
  assert.notEqual(p.main.trackId, 'microventure');
});

test('low runway selects a faster-income admissible track', () => {
  const p = C.clone(profile); p.runwayMonths = 1;
  const rec = C.recommendPortfolio(p, C.WORLD_MODELS, {}, DATE);
  assert.ok(track(rec.main.trackId).incomeSpeed >= .65);
});

test('Pareto frontier is non-empty and subset of evaluations', () => {
  const e = C.evaluateAllTracks(profile, C.WORLD_MODELS, {}, DATE);
  const f = C.paretoFrontier(e);
  assert.ok(f.length > 0);
  assert.ok(f.length <= e.length);
});

test('application funnel metrics are calculated consistently', () => {
  const apps = [
    {status:'target'}, {status:'saved'}, {status:'applied'}, {status:'test'},
    {status:'interview1'}, {status:'offer'}, {status:'rejected'}, {status:'withdrawn'}
  ];
  const m = C.applicationMetrics(apps);
  assert.equal(m.total, 8);
  assert.equal(m.applied, 6);
  assert.equal(m.responses, 4);
  assert.equal(m.interviews, 2);
  assert.equal(m.offers, 1);
  assert.equal(m.responseRate, C.round(4/6));
});

test('deadline states distinguish overdue, urgent and normal', () => {
  assert.equal(C.deadlineState('2026-08-30', DATE).level, 'danger');
  assert.equal(C.deadlineState('2026-09-04', DATE).level, 'danger');
  assert.equal(C.deadlineState('2026-09-10', DATE).level, 'warn');
  assert.equal(C.deadlineState('2026-10-10', DATE).level, 'good');
});

test('next actions tell an autumn applicant to enter pipeline now', () => {
  const actions = C.nextActions(state, DATE);
  assert.ok(actions.some(a=>a.title.includes('20个高匹配岗位池')));
  assert.ok(actions.some(a=>a.title.includes('证据冲刺')));
});

test('JD matcher identifies covered and missing skills', () => {
  const jd = '需要Excel、SQL、数据分析、跨部门项目管理和AI工作流能力。';
  const cv = '负责销售数据分析，用Excel建立看板，推动跨部门项目交付，转化率提升12%。另用大模型搭建AI工作流。';
  const r = C.matchJD(jd, cv);
  assert.ok(r.matched.some(x=>x.category==='Excel/表格'));
  assert.ok(r.matched.some(x=>x.category==='AI工具'));
  assert.ok(r.missing.some(x=>x.category==='SQL'));
  assert.ok(r.evidenceQuality > .2);
});

test('JD matcher warns against evidence-poor short resume', () => {
  const r = C.matchJD('要求SQL和Python', '会用电脑');
  assert.ok(r.warnings.length >= 1);
  assert.equal(r.coverage, 0);
});

test('scam scanner catches password and training-loan patterns', () => {
  const r = C.scanRecruitmentRisk('入职前先办理培训贷，并把短信验证码发给老师。');
  assert.equal(r.level, 'critical');
  assert.ok(r.hits.length >= 2);
});

test('scam scanner does not accuse normal recruitment text', () => {
  const r = C.scanRecruitmentRisk('请通过公司官网投递，面试不收取任何费用。');
  assert.equal(r.level, 'low');
  assert.equal(r.hits.length, 0);
  assert.match(r.nonClaim, /不能单独证明/);
});

test('offer vector exposes unsustainable hours and weak contract', () => {
  const o = { monthlySalary:8000, salaryMonths:12, annualBonus:0, monthlyHousingSupport:0, monthlyEssentialCost:4500,
    weeklyHours:68, commuteMinutes:100, contractClarity:.3, socialInsurance:.3, overtimeClarity:.2, exitReversibility:.4,
    learning:.5, managerQuality:.5, taskOwnership:.3, transferability:.5, aiSubstitutionRisk:.9, fieldRelation:.1,
    locationFit:.5, organisationStability:.5 };
  const v = C.offerVector(o, profile);
  assert.ok(v.redFlags.some(x=>x.includes('工作时长')));
  assert.ok(v.redFlags.some(x=>x.includes('合同')));
  assert.ok(v.robust <= .4);
});

test('offer Pareto frontier removes a strictly dominated offer', () => {
  const base = { salaryMonths:12, annualBonus:0, monthlyHousingSupport:0, monthlyEssentialCost:3000, weeklyHours:42, commuteMinutes:30,
    contractClarity:.8, socialInsurance:.8, overtimeClarity:.8, exitReversibility:.8, learning:.8, managerQuality:.8,
    taskOwnership:.8, transferability:.8, aiSubstitutionRisk:.3, fieldRelation:.6, locationFit:.8, organisationStability:.8 };
  const better = { ...base, id:'better', monthlySalary:10000 };
  const worse = { ...base, id:'worse', monthlySalary:6000, contractClarity:.6, socialInsurance:.6, learning:.6, locationFit:.6 };
  const f = C.offerPareto([better,worse], profile);
  assert.ok(f.some(x=>x.id==='better'));
  assert.ok(!f.some(x=>x.id==='worse'));
});

test('decision gates include autumn, spring and graduation gates', () => {
  const gates = C.buildDecisionGates(state, DATE);
  assert.equal(gates.length, 6);
  assert.ok(gates.some(g=>g.name.includes('秋招')));
  assert.ok(gates.some(g=>g.name.includes('春招')));
  assert.ok(gates.some(g=>g.name.includes('离校')));
});

test('career plan contains human-rights and no-fabrication invariants', () => {
  const p = C.makeCareerPlan(state, DATE);
  assert.equal(p.invariants.automatedHumanWorthRanking, 0);
  assert.equal(p.invariants.fakeExperienceGeneration, 0);
  assert.equal(p.invariants.externalAutomaticApplication, 0);
  assert.equal(p.invariants.userRevocationPrecedence, 1);
  assert.equal(p.portfolio.allocations.reduce((a,x)=>a+x.share,0), 100);
});

test('stable stringify and hash are deterministic', () => {
  const a = {z:1,a:{q:2,b:3}};
  const b = {a:{b:3,q:2},z:1};
  assert.equal(C.stableStringify(a), C.stableStringify(b));
  assert.equal(C.fnv1a(C.stableStringify(a)), C.fnv1a(C.stableStringify(b)));
});

test('skills extracted from mixed English and Chinese', () => {
  const cats = C.categoriesInText('Use Python, SQL, Docker and 项目管理 for 数据分析').map(x=>x.category);
  assert.ok(cats.includes('Python'));
  assert.ok(cats.includes('SQL'));
  assert.ok(cats.includes('代码工程'));
  assert.ok(cats.includes('项目管理'));
});


test('hash-chain verifier accepts valid chain and detects tampering', () => {
  const a = {id:'a',type:'x',payload:{n:1},prev:'GENESIS'}; a.hash=C.hashRecord(a);
  const b = {id:'b',type:'y',payload:{n:2},prev:a.hash}; b.hash=C.hashRecord(b);
  assert.equal(C.verifyHashChain([a,b]).valid, true);
  const bad = C.clone([a,b]); bad[0].payload.n=9;
  assert.equal(C.verifyHashChain(bad).valid, false);
});

test('stop rules protect against fake experience and paid referrals', () => {
  const rec = C.recommendPortfolio(profile, C.WORLD_MODELS, {}, DATE);
  assert.ok(rec.stopRules.some(x=>x.includes('付费内推')));
  assert.ok(rec.stopRules.some(x=>x.includes('不得写成已完成事实')));
});
