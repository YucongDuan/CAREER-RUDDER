# Security and privacy

The reference client is local-first and performs no automatic job applications, payments, credential submissions, or external API calls. It stores data in browser localStorage unless the user exports files.

Do not paste identity-card numbers, bank-card details, passwords, verification codes, unredacted contracts, health records or other unnecessary sensitive data. Use only official employer, school and public-service channels for verification.

Report implementation vulnerabilities with a minimal reproducible case. Do not include real student data in public issues.
