/* DIKWP CAREER RUDDER / ZHIDUO 17.0.0 browser client */
(function(){
  'use strict';
  const C = window.ZhiduoCore;
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const STORAGE_KEY = 'dikwp_zhiduo_17_state_v1';
  const memoryStorage = new Map();
  const storage = {
    getItem(key){ try { return window.localStorage.getItem(key); } catch (_) { return memoryStorage.has(key) ? memoryStorage.get(key) : null; } },
    setItem(key,value){ try { window.localStorage.setItem(key,value); } catch (_) { memoryStorage.set(key,String(value)); } },
    removeItem(key){ try { window.localStorage.removeItem(key); } catch (_) { memoryStorage.delete(key); } }
  };
  const TODAY = () => new Date();
  const esc = v => String(v ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
  const pct = v => `${Math.round(C.clamp(v)*100)}%`;
  const fmt = n => Number(n || 0).toLocaleString('zh-CN', { maximumFractionDigits: 2 });
  const uid = p => `${p}-${Date.now()}-${Math.random().toString(16).slice(2,8)}`;

  const OFFICIAL_SOURCES = [
    {
      title:'国家大学生就业服务平台：2027届招聘已经启动', status:'已核验', statusClass:'good', verified:'2026-09-02',
      note:'京东方2027届提前批自2026年7月启动；中国人保等单位已开放2027届招聘。具体岗位以各用人单位页面为准。',
      url:'https://www.ncss.cn/'
    },
    {
      title:'国务院国资委央企招聘栏目', status:'已核验', statusClass:'good', verified:'2026-09-02',
      note:'2026年9月1日前后已有航空工业、沈飞、航天科工等2027届校园招聘发布。',
      url:'https://www.sasac.gov.cn/n2588035/n2588325/n2588350/index.html'
    },
    {
      title:'2027全国硕士研究生招生考试', status:'等待正式公告', statusClass:'warn', verified:'2026-09-02',
      note:'本客户端不预填全国统一具体日期。只从研招网、教育部和报考点正式公告登记。',
      url:'https://yz.chsi.com.cn/'
    },
    {
      title:'2027年度中央机关公务员招录', status:'等待正式公告', statusClass:'warn', verified:'2026-09-02',
      note:'本客户端不沿用往年日期作为事实。公告发布后再登记报名、资格、笔试和面试节点。',
      url:'https://www.scs.gov.cn/'
    },
    {
      title:'高校毕业生公共就业服务与见习', status:'政策入口', statusClass:'good', verified:'2026-09-02',
      note:'未就业毕业生可关注公共就业服务、见习、培训、基层项目和困难帮扶；具体资格以当地政策为准。',
      url:'https://www.mohrss.gov.cn/'
    },
    {
      title:'求职安全与招聘陷阱提示', status:'长期有效', statusClass:'danger', verified:'2026-09-02',
      note:'警惕黑中介、付费内推、培训贷、押金、刷单垫资和非法传销。',
      url:'https://www.moe.gov.cn/jyb_xwfb/gzdt_gzdt/s5987/202405/t20240521_1131747.html'
    }
  ];

  const STATUS_LABELS = {
    target:'目标', saved:'待投', applied:'已投', test:'笔试/测评', interview1:'一面', interview2:'二面', final:'终面/背调', offer:'Offer', rejected:'拒绝', withdrawn:'主动放弃'
  };

  function demoState(){
    const p = C.clone(C.DEFAULT_PROFILE);
    return {
      version:C.VERSION, profile:p, worlds:C.clone(C.WORLD_MODELS), ui:{view:'dashboard'},
      applications:[
        {id:'app-demo-1',company:'某央企数字化子公司（演示）',role:'运营管理培训生',trackId:'state_owned',status:'applied',deadline:'2026-09-20',source:'单位官网（演示字段）',resume:'运营版 v1',match:.76,note:'补充供应链项目证据；此条不是现实岗位'},
        {id:'app-demo-2',company:'某制造企业（演示）',role:'供应链运营',trackId:'industrial_ops',status:'test',deadline:'2026-09-12',source:'学校就业网（演示字段）',resume:'供应链版 v2',match:.82,note:'准备库存与流程案例；此条不是现实岗位'},
        {id:'app-demo-3',company:'某科技服务公司（演示）',role:'AI业务运营',trackId:'private_ai_ops',status:'interview1',deadline:'2026-09-15',source:'企业官网（演示字段）',resume:'AI运营版 v2',match:.85,note:'准备人机分工、验证和结果指标；此条不是现实岗位'}
      ],
      evidence:[
        {id:'ev-demo-1',title:'课程团队项目：校园活动运营复盘',type:'项目作品',status:'self',date:'2026-06-20',source:'本地文件/演示',claim:'能够完成基础活动策划与复盘',metric:'参与者48人；满意度为本人课程记录，未独立复核',prev:'GENESIS',hash:'demo0001'},
        {id:'ev-demo-2',title:'实习主管反馈摘要',type:'实习成果',status:'stakeholder',date:'2026-08-10',source:'主管邮件摘要/演示',claim:'能够按时完成流程整理和周报',metric:'连续6周按期交付；此条为合成演示',prev:'demo0001',hash:'demo0002'}
      ],
      deadlines:[
        {id:'d-official-1',title:'中国东方资产2027校招报名截止（示例官方岗位）',date:'2026-09-18',type:'央国企',status:'official',source:'国家大学生就业服务平台；仅作时间敏感性示例'},
        {id:'d-plan-1',title:'完成首批20个高匹配岗位池',date:'2026-09-10',type:'企业招聘',status:'planning',source:'个人行动门，不是官方截止日'},
        {id:'d-plan-2',title:'秋招第一轮复盘',date:'2026-10-15',type:'学校事项',status:'planning',source:'职舵规划窗口'},
        {id:'d-official-2',title:'中国人保2027校招通道整体截止（单位公告）',date:'2027-04-25',type:'央国企',status:'official',source:'国家大学生就业服务平台；具体岗位可能分批结束'},
        {id:'d-grad',title:'预计毕业日期',date:p.graduationDate,type:'学校事项',status:'planning',source:'个人填写'}
      ],
      offers:[], receipts:[], lastMatch:null, lastRisk:null
    };
  }

  function normalizeState(input){
    const src = input && typeof input === 'object' ? input : {};
    const base = C.clone(C.DEFAULT_PROFILE);
    const profile = { ...base, ...(src.profile || {}) };
    profile.skills = { ...base.skills, ...((src.profile || {}).skills || {}) };
    profile.evidenceCounts = { ...base.evidenceCounts, ...((src.profile || {}).evidenceCounts || {}) };
    return {
      version: C.VERSION,
      profile,
      worlds: Array.isArray(src.worlds) && src.worlds.length ? src.worlds : C.clone(C.WORLD_MODELS),
      ui: { view: src.ui?.view || 'dashboard' },
      applications: Array.isArray(src.applications) ? src.applications : [],
      evidence: Array.isArray(src.evidence) ? src.evidence : [],
      deadlines: Array.isArray(src.deadlines) ? src.deadlines : [],
      offers: Array.isArray(src.offers) ? src.offers : [],
      receipts: Array.isArray(src.receipts) ? src.receipts : [],
      lastMatch: src.lastMatch || null,
      lastRisk: src.lastRisk || null
    };
  }

  function sealDemoEvidence(s){
    let prev = 'GENESIS';
    s.evidence = (s.evidence || []).map(e => {
      const row = { ...e, prev };
      delete row.hash;
      row.hash = C.hashRecord(row);
      prev = row.hash;
      return row;
    });
    return s;
  }

  let state = normalizeState(sealDemoEvidence(demoState()));

  function loadStored(){
    try{
      const raw = storage.getItem(STORAGE_KEY);
      if(raw){
        const parsed = JSON.parse(raw);
        if(parsed && parsed.profile) state = normalizeState(parsed);
      }
    }catch(e){ console.warn('Could not load local state', e); }
  }
  function save(silent=false){
    storage.setItem(STORAGE_KEY, JSON.stringify(state));
    if(!silent) toast('已保存到本机浏览器');
  }
  function addReceipt(type,payload){
    state.receipts = state.receipts || [];
    const prev = state.receipts.length ? state.receipts[state.receipts.length-1].hash : 'GENESIS';
    const r = {id:uid('r'),at:new Date().toISOString(),type,payload,prev};
    r.hash = C.fnv1a(C.stableStringify(r)); state.receipts.push(r); return r;
  }
  function toast(msg){ const el=$('#toast'); el.textContent=msg; el.classList.add('show'); clearTimeout(toast.t); toast.t=setTimeout(()=>el.classList.remove('show'),2200); }
  function navigate(view){
    $$('.view').forEach(v=>v.classList.toggle('active',v.id===view));
    $$('#nav button').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
    state.ui={...(state.ui||{}),view}; $('#sidebar').classList.remove('open'); window.scrollTo(0,0);
    if(view==='export') renderPlan();
  }
  function download(filename,content,type='text/plain;charset=utf-8'){
    const blob=new Blob([content],{type}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=filename; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function csvCell(v){ return `"${String(v??'').replace(/"/g,'""')}"`; }
  function trackById(id){ return C.TRACKS.find(t=>t.id===id); }
  function context(){ return {evidenceCount:(state.evidence||[]).length}; }
  function currentPortfolio(){ return C.recommendPortfolio(state.profile,state.worlds,context(),TODAY()); }

  function renderDashboard(){
    const phase=C.phaseFor(TODAY(),state.profile.graduationDate); const m=C.applicationMetrics(state.applications); const pf=currentPortfolio();
    $('#studentTitle').textContent=state.profile.name;
    const robust=pf.main.worst;
    const metrics=[
      ['距毕业',`${phase.daysToGrad}天`,'不是等待期，而是剩余决策窗口',phase.daysToGrad<180?'warn':'good'],
      ['当前阶段',phase.zh,phase.priority,'good'],
      ['已投岗位',m.applied,`有效回复 ${m.responses} · 面试 ${m.interviews}`,m.applied<10?'warn':'good'],
      ['证据条目',(state.evidence||[]).length,`第三方确认 ${(state.evidence||[]).filter(e=>e.status!=='self').length}`,(state.evidence||[]).length<3?'warn':'good'],
      ['主路径最坏世界',pct(robust),'规划压力测试，不是录用概率',robust<.45?'danger':robust<.6?'warn':'good']
    ];
    $('#dashboardMetrics').innerHTML=metrics.map(x=>`<div class="card metric ${x[3]}"><div class="label">${esc(x[0])}</div><div class="value">${esc(x[1])}</div><div class="sub">${esc(x[2])}</div></div>`).join('');
    $('#phaseAdvice').innerHTML=`<div class="callout ${phase.id==='autumn_main'?'danger':'warn'}"><strong>${esc(phase.zh)}</strong><br>${esc(phase.priority)}</div><p>截至系统数据核验日，2027届部分招聘已在2026年7—9月启动。软件因此把“先进入真实管道，再边投边修订”设为默认，而不是等到2027年。</p>`;
    $('#portfolioSummary').innerHTML=`<div class="portfolio-strip">${pf.allocations.map(a=>`<div class="portfolio-block"><b>${esc(a.role)}</b><strong>${esc(a.name)}</strong><div class="share">${a.share}%</div><small>${Math.round(state.profile.weeklyHours*a.share/100)}小时/周</small></div>`).join('')}</div>`;
    $('#nextActions').innerHTML=C.nextActions(state,TODAY()).map((a,i)=>`<div class="action-item"><div class="action-no">${i+1}</div><div><h4>${esc(a.title)}</h4><p>${esc(a.why)}</p><div class="proof">必须留下：${esc(a.evidence)}</div></div><span class="status ${a.priority===1?'danger':a.priority===2?'warn':'good'}">P${a.priority}</span></div>`).join('');
    const mainEval=pf.main;
    $('#worldBars').innerHTML=C.normalizeWorlds(state.worlds).map(w=>`<div class="list-item"><div style="display:flex;justify-content:space-between"><strong>${esc(w.zh)}</strong><span>${pct(mainEval.worldScores[w.id])}</span></div><small>${esc(w.description)}</small><div class="bar ${mainEval.worldScores[w.id]<.45?'danger':mainEval.worldScores[w.id]<.6?'warn':''}" style="margin-top:8px"><span style="width:${pct(mainEval.worldScores[w.id])}"></span></div></div>`).join('');
    const stages=['target','saved','applied','test','interview1','interview2','final','offer'];
    const stageCount=Object.fromEntries(stages.map(s=>[s,state.applications.filter(a=>a.status===s).length]));
    $('#funnelSummary').innerHTML=`<div class="grid cols-4">${stages.map(s=>`<div class="list-item"><strong>${esc(STATUS_LABELS[s])}</strong><div style="font-size:26px;font-weight:900;color:var(--cyan);margin-top:6px">${stageCount[s]}</div></div>`).join('')}</div><p>反馈率 ${pct(m.responseRate)} · 面试率 ${pct(m.interviewRate)} · Offer率 ${pct(m.offerRate)}。这些只描述当前管道，不评价个人价值。</p>`;
  }

  function populateProfile(){
    const p=state.profile;
    $('#p_majorCluster').innerHTML=C.MAJOR_CLUSTERS.map(([id,name])=>`<option value="${id}">${esc(name)}</option>`).join('');
    const simple=['name','degree','schoolType','majorCluster','major','graduationDate','currentCity','targetRegions','weeklyHours','runwayMonths','monthlyBudget','minimumMonthlyCash','purpose','nonNegotiables'];
    simple.forEach(k=>{ const el=$(`#p_${k}`); if(el) el.value=p[k]??''; });
    ['stabilityPreference','relocationFlexibility','familyBurden','healthEnergy','publicServiceFit','postgraduateSpecificity','researchCommitment','ventureEvidence'].forEach(k=>{
      const el=$(`#p_${k}`); el.value=p[k]??0; el.parentElement.querySelector('output').textContent=pct(p[k]);
    });
    $('#p_mustFormalSocialInsurance').checked=!!p.mustFormalSocialInsurance; $('#p_cannotHighDebt').checked=!!p.cannotHighDebt;
    $('#skillInputs').innerHTML=C.SKILLS.map(s=>`<div class="field"><label>${esc(s.zh)}</label><div class="range-row"><input data-skill="${s.id}" type="range" min="0" max="1" step="0.01" value="${p.skills?.[s.id]??0}"><output>${pct(p.skills?.[s.id]??0)}</output></div></div>`).join('');
    Object.entries(p.evidenceCounts||{}).forEach(([k,v])=>{const el=$(`#ec_${k}`);if(el)el.value=v;});
  }

  function bindProfileEvents(){
    const textKeys=['name','degree','schoolType','majorCluster','major','graduationDate','currentCity','targetRegions','purpose','nonNegotiables'];
    textKeys.forEach(k=>$(`#p_${k}`).addEventListener('input',e=>{state.profile[k]=e.target.value;renderDashboard();}));
    ['weeklyHours','runwayMonths','monthlyBudget','minimumMonthlyCash'].forEach(k=>$(`#p_${k}`).addEventListener('input',e=>{state.profile[k]=Number(e.target.value);renderDashboard();}));
    ['stabilityPreference','relocationFlexibility','familyBurden','healthEnergy','publicServiceFit','postgraduateSpecificity','researchCommitment','ventureEvidence'].forEach(k=>$(`#p_${k}`).addEventListener('input',e=>{state.profile[k]=Number(e.target.value);e.target.parentElement.querySelector('output').textContent=pct(e.target.value);renderDashboard();}));
    ['mustFormalSocialInsurance','cannotHighDebt'].forEach(k=>$(`#p_${k}`).addEventListener('change',e=>{state.profile[k]=e.target.checked;renderDashboard();}));
    $('#skillInputs').addEventListener('input',e=>{if(e.target.dataset.skill){state.profile.skills[e.target.dataset.skill]=Number(e.target.value);e.target.parentElement.querySelector('output').textContent=pct(e.target.value);renderDashboard();}});
    ['internships','projects','externalVerifications','quantifiedStories'].forEach(k=>$(`#ec_${k}`).addEventListener('input',e=>{state.profile.evidenceCounts[k]=Number(e.target.value);renderDashboard();renderEvidence();}));
  }

  function renderTracks(){
    const pf=currentPortfolio(); const frontier=new Set(pf.frontier);
    $('#portfolioDetail').innerHTML=`<div class="portfolio-strip">${pf.allocations.map(a=>`<div class="portfolio-block"><b>${esc(a.role)}</b><strong>${esc(a.name)}</strong><div class="share">${a.share}%</div><small>${Math.round(state.profile.weeklyHours*a.share/100)}小时/周</small></div>`).join('')}</div><p>主路径选择理由：预期可行度 ${pct(pf.main.expected)}，最坏世界 ${pct(pf.main.worst)}，可逆与证据期权 ${pct(pf.main.optionValue)}。异质对冲不会与主路径共享完全相同的失败原因。</p>`;
    $('#trackCards').innerHTML=pf.evaluations.map((e,i)=>{
      const t=trackById(e.trackId); const gap=e.gaps.map(g=>`<span class="tag warn">缺口：${esc(g.name)} ${pct(g.gap)}</span>`).join('');
      const flags=[...e.blockers.map(x=>`<span class="tag danger">${esc(x)}</span>`),...e.cautions.map(x=>`<span class="tag warn">${esc(x)}</span>`)].join('');
      return `<div class="card track-card ${frontier.has(e.trackId)?'frontier':''}"><div class="track-head"><div><div class="eyebrow">${frontier.has(e.trackId)?'PARETO FRONTIER':'TRACK '+(i+1)}</div><h3>${esc(e.trackName)}</h3></div><div class="track-score">${Math.round(e.advisoryIndex*100)}</div></div><p>${esc(t.desc)}</p><div class="track-meta"><div><b>${pct(e.worst)}</b><span>最坏世界</span></div><div><b>${pct(e.readiness)}</b><span>证据就绪</span></div><div><b>${pct(e.optionValue)}</b><span>可逆期权</span></div><div><b>${pct(e.lockIn)}</b><span>锁定成本</span></div></div><div class="tag-list" style="margin-top:12px">${gap||'<span class="tag">核心能力基本覆盖</span>'}</div>${flags?`<div class="tag-list" style="margin-top:8px">${flags}</div>`:''}<p><strong>建议证据：</strong>${esc(t.proof.join('、'))}</p></div>`;
    }).join('');
    $('#stopRules').innerHTML=pf.stopRules.map(r=>`<li>${esc(r)}</li>`).join('');
  }

  function populateTrackSelects(){
    const opts=C.TRACKS.map(t=>`<option value="${t.id}">${esc(t.zh)}</option>`).join('');
    $('#a_track').innerHTML=opts; $('#o_track').innerHTML=opts;
  }

  function renderPipeline(){
    const m=C.applicationMetrics(state.applications);
    const metrics=[['岗位池',m.total,'全部记录'],['已投',m.applied,'不含收藏/目标'],['有效回复',m.responses,`反馈率 ${pct(m.responseRate)}`],['面试',m.interviews,`面试率 ${pct(m.interviewRate)}`],['Offer',m.offers,`Offer率 ${pct(m.offerRate)}`]];
    $('#pipelineMetrics').innerHTML=metrics.map((x,i)=>`<div class="card metric ${i===4&&x[1]>0?'good':i===1&&x[1]<10?'warn':''}"><div class="label">${x[0]}</div><div class="value">${x[1]}</div><div class="sub">${x[2]}</div></div>`).join('');
    if(!state.applications.length){$('#applicationsTable').innerHTML='<tr><td colspan="7" class="empty">尚无岗位。现在建立第一批目标岗位池。</td></tr>';return;}
    $('#applicationsTable').innerHTML=state.applications.slice().sort((a,b)=>(a.deadline||'9999').localeCompare(b.deadline||'9999')).map(a=>{
      const dl=C.deadlineState(a.deadline,TODAY());
      return `<tr><td><strong>${esc(a.company)}</strong><br>${esc(a.role)}</td><td>${esc(trackById(a.trackId)?.zh||a.trackId)}</td><td><select data-app-status="${esc(a.id)}">${Object.entries(STATUS_LABELS).map(([k,v])=>`<option value="${k}" ${a.status===k?'selected':''}>${v}</option>`).join('')}</select></td><td>${esc(a.deadline||'—')}<br><span class="status ${dl.level}">${esc(dl.label)}</span></td><td>${esc(a.source||'—')}<br><small>${esc(a.resume||'—')}</small></td><td>${pct(a.match)}<br><small>${esc(a.note||'')}</small></td><td><button class="btn small danger" data-delete-app="${esc(a.id)}">删除</button></td></tr>`;
    }).join('');
    $$('[data-app-status]').forEach(el=>el.addEventListener('change',e=>{const a=state.applications.find(x=>x.id===e.target.dataset.appStatus);if(a){a.status=e.target.value;addReceipt('application_status',{id:a.id,status:a.status});renderAll();save(true);}}));
    $$('[data-delete-app]').forEach(el=>el.addEventListener('click',e=>{state.applications=state.applications.filter(x=>x.id!==e.target.dataset.deleteApp);addReceipt('application_removed',{id:e.target.dataset.deleteApp});renderAll();save(true);}));
  }

  function addApplication(){
    const company=$('#a_company').value.trim(),role=$('#a_role').value.trim(); if(!company||!role)return toast('请填写单位和岗位');
    const a={id:uid('app'),company,role,trackId:$('#a_track').value,status:$('#a_status').value,deadline:$('#a_deadline').value,source:$('#a_source').value.trim(),resume:$('#a_resume').value.trim(),match:Number($('#a_match').value),note:$('#a_note').value.trim()};
    state.applications.push(a);addReceipt('application_added',{id:a.id,company,role});['a_company','a_role','a_deadline','a_source','a_resume','a_note'].forEach(id=>$('#'+id).value='');renderAll();save(true);toast('岗位已加入管道');
  }

  function renderMatch(){
    const r=state.lastMatch;if(!r){$('#matchResults').className='empty';$('#matchResults').innerHTML='尚未分析。';return;}
    $('#matchResults').className='match-results';
    $('#matchResults').innerHTML=`<div class="grid cols-3"><div><div class="big-score">${Math.round(r.coverage*100)}%</div><small>JD关键词覆盖</small></div><div><div class="big-score" style="color:var(--green)">${Math.round(r.evidenceQuality*100)}%</div><small>简历证据表达代理值</small></div><div><span class="status ${r.coverage>=.7?'good':r.coverage>=.45?'warn':'danger'}">${r.coverage>=.7?'可进入定制':r.coverage>=.45?'需补证据':'不宜直接投递'}</span></div></div><div><h3>已覆盖</h3><div class="keyword-cloud">${r.matched.map(x=>`<span class="keyword matched">${esc(x.category)}</span>`).join('')||'<span class="keyword">无</span>'}</div></div><div><h3>缺失或未写出</h3><div class="keyword-cloud">${r.missing.map(x=>`<span class="keyword missing">${esc(x.category)}</span>`).join('')||'<span class="keyword matched">未识别到明显缺口</span>'}</div></div>${r.warnings.length?`<div class="callout warn">${r.warnings.map(esc).join('<br>')}</div>`:''}<div><h3>补证据问题</h3><ul>${r.questions.map(q=>`<li>${esc(q)}</li>`).join('')||'<li>把已有经历写成对象—动作—结果—证据，不增加不存在的事实。</li>'}</ul></div>`;
  }

  function addEvidence(data){
    const prev=state.evidence.length?state.evidence[state.evidence.length-1].hash:'GENESIS';
    const e={id:uid('ev'),date:new Date().toISOString().slice(0,10),status:'self',...data,prev};e.hash=C.fnv1a(C.stableStringify(e));state.evidence.push(e);addReceipt('evidence_added',{id:e.id,hash:e.hash});return e;
  }
  function renderEvidence(){
    const pf=currentPortfolio(); const mainTrack=trackById(pf.main.trackId); const gaps=pf.main.gaps;
    const sprint=[
      ['第1—2天','选择一个真实岗位簇和一个可交付问题','目标JD、问题所有者、允许使用的数据'],
      ['第3—5天',`补第一缺口：${gaps[0]?.name||'成果证据'}`,'一个小型可查看工件'],
      ['第6—8天',`补第二缺口：${gaps[1]?.name||'AI协作与验证'}`,'过程记录、检查表或测试结果'],
      ['第9—11天','让真实使用者或导师验证','反馈、修改前后差异和边界'],
      ['第12—14天','形成简历、面试和作品集三种表达','一条量化STAR＋作品链接/文件＋失败复盘']
    ];
    $('#proofSprint').innerHTML=`<p><strong>当前主路径：</strong>${esc(mainTrack.zh)}</p>${sprint.map(s=>`<div class="list-item"><strong>${s[0]} · ${esc(s[1])}</strong><small>证据：${esc(s[2])}</small></div>`).join('')}`;
    const stories=state.evidence.filter(e=>e.status!=='self'||e.metric).slice(-4).reverse();
    $('#proofStories').innerHTML=stories.length?stories.map(e=>`<div class="list-item"><strong>${esc(e.title)}</strong><small>情境/任务：${esc(e.claim)}<br>结果与边界：${esc(e.metric||'待补充')}<br>验证：${esc(e.status)}</small></div>`).join(''):'<div class="empty">先写入一条有结果或第三方确认的证据。</div>';
    if(!state.evidence.length){$('#evidenceTable').innerHTML='<tr><td colspan="7" class="empty">尚无证据。</td></tr>';return;}
    $('#evidenceTable').innerHTML=state.evidence.slice().reverse().map(e=>`<tr><td><strong>${esc(e.title)}</strong><br><small>${esc(e.type)} · ${esc(e.date)}</small></td><td>${esc(e.claim)}</td><td>${esc(e.metric||'—')}</td><td><span class="status ${e.status==='independent'?'good':e.status==='stakeholder'?'warn':'muted'}">${esc(e.status)}</span></td><td>${esc(e.source||'—')}</td><td class="receipt">${esc(e.hash)}</td><td><button class="btn small danger" data-delete-evidence="${esc(e.id)}">删除</button></td></tr>`).join('');
    $$('[data-delete-evidence]').forEach(el=>el.addEventListener('click',e=>{state.evidence=state.evidence.filter(x=>x.id!==e.target.dataset.deleteEvidence);addReceipt('evidence_removed',{id:e.target.dataset.deleteEvidence});renderAll();save(true);}));
  }

  function renderCalendar(){
    $('#officialSources').innerHTML=OFFICIAL_SOURCES.map(s=>`<div class="card source-card"><div class="eyebrow">OFFICIAL SOURCE REGISTER</div><h3>${esc(s.title)}</h3><span class="status ${s.statusClass}">${esc(s.status)}</span><p>${esc(s.note)}</p><div class="source-meta">核验：${esc(s.verified)}</div><p><a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">打开官方入口 ↗</a></p></div>`).join('');
    const rows=state.deadlines.slice().sort((a,b)=>(a.date||'9999').localeCompare(b.date||'9999'));
    $('#deadlinesTable').innerHTML=rows.length?rows.map(d=>{const ds=C.deadlineState(d.date,TODAY());return `<tr><td>${esc(d.date)}</td><td><strong>${esc(d.title)}</strong></td><td>${esc(d.type)}</td><td><span class="status ${d.status==='official'?'good':d.status==='planning'?'warn':'danger'}">${esc(d.status==='official'?'官方公告':d.status==='planning'?'规划窗口':'待核验')}</span></td><td><span class="status ${ds.level}">${esc(ds.label)}</span></td><td>${esc(d.source||'')}</td><td><button class="btn small danger" data-delete-deadline="${esc(d.id)}">删除</button></td></tr>`}).join(''):'<tr><td colspan="7" class="empty">暂无节点。</td></tr>';
    $$('[data-delete-deadline]').forEach(el=>el.addEventListener('click',e=>{state.deadlines=state.deadlines.filter(x=>x.id!==e.target.dataset.deleteDeadline);addReceipt('deadline_removed',{id:e.target.dataset.deleteDeadline});renderCalendar();save(true);}));
    $('#decisionGates').innerHTML=C.buildDecisionGates(state,TODAY()).map(g=>`<div class="card gate"><div class="eyebrow">${esc(g.date)} · ${esc(g.deadline.label)}</div><h3>${esc(g.name)}</h3><strong>继续条件</strong><ul>${g.continueIf.map(x=>`<li>${esc(x)}</li>`).join('')}</ul><strong>转向条件</strong><ul>${g.pivotIf.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>`).join('');
  }

  function renderOffers(){
    const frontier=new Set(C.offerPareto(state.offers,state.profile).map(o=>o.id));
    if(!state.offers.length){$('#offerCards').innerHTML='<div class="card empty" style="grid-column:1/-1">尚无Offer。可先输入模拟数据熟悉比较逻辑。</div>';return;}
    $('#offerCards').innerHTML=state.offers.map(o=>{const v=C.offerVector(o,state.profile);return `<div class="card offer-card"><div class="track-head"><div><div class="eyebrow">${frontier.has(o.id)?'PARETO FRONTIER':'OFFER'}</div><h3>${esc(o.name)}</h3><p>${esc(o.role)} · ${esc(trackById(o.trackId)?.zh||'')}</p></div><div class="track-score">${pct(v.robust)}</div></div><div class="vector-grid"><div><b>¥${fmt(v.monthlyCashProxy)}</b><span>月度现金结余代理</span></div><div><b>${pct(v.growth)}</b><span>成长</span></div><div><b>${pct(v.health)}</b><span>可持续</span></div><div><b>${pct(v.rights)}</b><span>合同与权益</span></div><div><b>${pct(v.aiResilience)}</b><span>AI韧性</span></div><div><b>${pct(v.location)}</b><span>地点</span></div><div><b>${pct(v.stability)}</b><span>组织稳定</span></div><div><b>${pct(v.cash)}</b><span>现金底线</span></div></div>${v.redFlags.length?`<div class="tag-list" style="margin-top:12px">${v.redFlags.map(x=>`<span class="tag danger">${esc(x)}</span>`).join('')}</div>`:'<div class="tag-list" style="margin-top:12px"><span class="tag">未触发预设红线，仍需核验合同</span></div>'}<div style="margin-top:12px"><button class="btn small danger" data-delete-offer="${esc(o.id)}">删除</button></div></div>`}).join('');
    $$('[data-delete-offer]').forEach(el=>el.addEventListener('click',e=>{state.offers=state.offers.filter(x=>x.id!==e.target.dataset.deleteOffer);addReceipt('offer_removed',{id:e.target.dataset.deleteOffer});renderOffers();renderDashboard();save(true);}));
  }

  function renderRisk(){
    const r=state.lastRisk;if(!r){$('#riskResults').className='empty';$('#riskResults').innerHTML='尚未扫描。';return;}
    const color=r.level==='critical'||r.level==='high'?'var(--red)':r.level==='medium'?'var(--amber)':'var(--green)';
    $('#riskResults').className='risk-result';
    $('#riskResults').innerHTML=`<div class="risk-gauge" style="background:conic-gradient(${color} 0 ${Math.max(4,Math.round(r.score*100))}%,rgba(255,255,255,.06) ${Math.max(4,Math.round(r.score*100))}%)"><strong>${esc(r.level.toUpperCase())}</strong></div><div><h3>${r.hits.length?`发现${r.hits.length}类风险信号`:'未命中预设高风险词'}</h3>${r.hits.map(h=>`<div class="list-item"><strong>${esc(h.label)}</strong><small>${esc(h.advice)}</small></div>`).join('')}<p>${esc(r.nonClaim)}</p></div>`;
  }

  function planHtml(){
    const p=C.makeCareerPlan(state,TODAY()); const main=trackById(p.portfolio.main.trackId); const hedge=trackById(p.portfolio.hedge.trackId);
    const apps=p.applications.slice(0,30).map(a=>`<tr><td>${esc(a.company)}</td><td>${esc(a.role)}</td><td>${esc(STATUS_LABELS[a.status]||a.status)}</td><td>${esc(a.deadline||'—')}</td></tr>`).join('');
    return `<div class="eyebrow" style="color:#16779d">DIKWP CAREER RUDDER / ZHIDUO 17.0.0</div><h2>${esc(p.profile.name)} · 2027就业行动方案</h2><p><strong>生成时间：</strong>${esc(new Date(p.generatedAt).toLocaleString())}　<strong>预计毕业：</strong>${esc(p.profile.graduationDate)}</p><h3>Purpose与底线</h3><p>${esc(p.profile.purpose)}</p><p><strong>不可交易底线：</strong>${esc(p.profile.nonNegotiables)}</p><h3>当前阶段</h3><p><strong>${esc(p.phase.zh)}</strong>：${esc(p.phase.priority)}；距毕业约${p.phase.daysToGrad}天。</p><h3>路径组合</h3><table><thead><tr><th>角色</th><th>路径</th><th>投入</th><th>关键边界</th></tr></thead><tbody><tr><td>主路径</td><td>${esc(main.zh)}</td><td>${p.portfolio.allocations[0].share}%</td><td>${esc(p.portfolio.main.blockers.join('；')||'通过当前主路径硬门')}</td></tr><tr><td>异质对冲</td><td>${esc(hedge.zh)}</td><td>${p.portfolio.allocations[1].share}%</td><td>不与主路径共享完全相同的失败原因</td></tr><tr><td>共同底座</td><td>作品、AI协作、求职管道与真实证据</td><td>${p.portfolio.allocations[2].share}%</td><td>不得省略，不得伪造</td></tr></tbody></table><h3>未来7天行动</h3><ol>${p.nextActions.map(a=>`<li><strong>${esc(a.title)}</strong>：${esc(a.why)}；证据：${esc(a.evidence)}</li>`).join('')}</ol><h3>招聘管道</h3><p>已投${p.applicationMetrics.applied}，有效回复${p.applicationMetrics.responses}，面试${p.applicationMetrics.interviews}，Offer ${p.applicationMetrics.offers}。</p><table><thead><tr><th>单位</th><th>岗位</th><th>状态</th><th>截止</th></tr></thead><tbody>${apps||'<tr><td colspan="4">暂无记录</td></tr>'}</tbody></table><h3>停止与转向规则</h3><ul>${p.portfolio.stopRules.map(r=>`<li>${esc(r)}</li>`).join('')}</ul><h3>非主张</h3><ul>${p.nonClaims.map(x=>`<li>${esc(x)}</li>`).join('')}</ul><p class="receipt">Plan checksum: ${C.fnv1a(C.stableStringify(p))}</p>`;
  }
  function renderPlan(){ $('#planPreview').innerHTML=planHtml(); }

  function wireLabels(){
    $$('.field').forEach(field => {
      const label = field.querySelector('label');
      const control = field.querySelector('input,select,textarea');
      if(label && control?.id) label.htmlFor = control.id;
    });
  }

  function renderAll(){
    renderDashboard(); populateProfile(); renderTracks(); renderPipeline(); renderMatch(); renderEvidence(); renderCalendar(); renderOffers(); renderRisk(); renderPlan(); wireLabels(); navigate(state.ui?.view||'dashboard');
  }

  function bindEvents(){
    $$('#nav button').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.view)));
    $$('[data-jump]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.jump)));
    $('#mobileMenu').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
    $('#saveState').addEventListener('click',()=>{addReceipt('manual_save',{});save();});
    $('#loadDemo').addEventListener('click',()=>{state=normalizeState(sealDemoEvidence(demoState()));addReceipt('demo_loaded',{});renderAll();save(true);toast('已载入2027届工商管理演示案例');});
    $('#recompute').addEventListener('click',()=>{addReceipt('recomputed',{portfolio:currentPortfolio().allocations});renderAll();save(true);toast('已按当前证据重新计算');});
    $('#recommendPortfolio').addEventListener('click',()=>{addReceipt('portfolio_recommended',{portfolio:currentPortfolio().allocations});renderTracks();renderDashboard();renderPlan();toast('路径组合已更新');});
    bindProfileEvents();
    $('#addApplication').addEventListener('click',addApplication);
    $('#exportApplications').addEventListener('click',()=>{
      const head=['单位','岗位','路径','状态','截止日','来源','简历版本','匹配度','备注'];
      const lines=[head.map(csvCell).join(','),...state.applications.map(a=>[a.company,a.role,trackById(a.trackId)?.zh||a.trackId,STATUS_LABELS[a.status]||a.status,a.deadline,a.source,a.resume,a.match,a.note].map(csvCell).join(','))];
      download(`职舵2027_岗位管道_${Date.now()}.csv`,'\ufeff'+lines.join('\n'),'text/csv;charset=utf-8');
    });
    $('#runMatcher').addEventListener('click',()=>{state.lastMatch=C.matchJD($('#jdText').value,$('#resumeText').value);addReceipt('jd_match',{coverage:state.lastMatch.coverage,evidenceQuality:state.lastMatch.evidenceQuality});renderMatch();save(true);});
    $('#saveMatchEvidence').addEventListener('click',()=>{if(!state.lastMatch)return toast('请先分析');addEvidence({title:'简历—JD匹配报告',type:'JD匹配报告',status:'self',source:'职舵本地分析',claim:`JD关键词覆盖${Math.round(state.lastMatch.coverage*100)}%`,metric:`证据表达代理值${Math.round(state.lastMatch.evidenceQuality*100)}%；缺口：${state.lastMatch.missing.map(x=>x.category).join('、')||'无明显缺口'}`});renderAll();save(true);toast('已保存到证据账本');});
    $('#addEvidence').addEventListener('click',()=>{const title=$('#e_title').value.trim(),claim=$('#e_claim').value.trim();if(!title||!claim)return toast('请填写标题和主张');addEvidence({title,type:$('#e_type').value,status:$('#e_status').value,date:$('#e_date').value||new Date().toISOString().slice(0,10),source:$('#e_source').value.trim(),claim,metric:$('#e_metric').value.trim()});['e_title','e_source','e_claim','e_metric'].forEach(id=>$('#'+id).value='');renderAll();save(true);toast('证据已写入本地账本');});
    $('#addDeadline').addEventListener('click',()=>{const title=$('#d_title').value.trim(),date=$('#d_date').value;if(!title||!date)return toast('请填写事项和日期');const d={id:uid('d'),title,date,type:$('#d_type').value,status:$('#d_status').value,source:$('#d_source').value.trim()};state.deadlines.push(d);addReceipt('deadline_added',{id:d.id});['d_title','d_date','d_source'].forEach(id=>$('#'+id).value='');renderCalendar();save(true);toast('节点已加入');});
    $('#addOffer').addEventListener('click',()=>{const name=$('#o_name').value.trim(),role=$('#o_role').value.trim();if(!name||!role)return toast('请填写Offer名称和岗位');const val=id=>Number($('#'+id).value);const o={id:uid('offer'),name,role,trackId:$('#o_track').value,monthlySalary:val('o_salary'),salaryMonths:val('o_months'),annualBonus:val('o_bonus'),monthlyHousingSupport:val('o_housing'),monthlyEssentialCost:val('o_cost'),weeklyHours:val('o_hours'),commuteMinutes:val('o_commute'),learning:val('o_learning'),managerQuality:val('o_manager'),taskOwnership:val('o_ownership'),transferability:val('o_transfer'),aiSubstitutionRisk:val('o_aiRisk'),fieldRelation:val('o_field'),contractClarity:val('o_contract'),socialInsurance:val('o_social'),overtimeClarity:val('o_overtime'),exitReversibility:val('o_exit'),organisationStability:val('o_stability'),locationFit:val('o_location')};state.offers.push(o);addReceipt('offer_added',{id:o.id,name});renderOffers();renderDashboard();renderPlan();save(true);toast('Offer已加入多维比较');});
    $('#scanRisk').addEventListener('click',()=>{state.lastRisk=C.scanRecruitmentRisk($('#riskText').value);addReceipt('risk_scan',{level:state.lastRisk.level,hits:state.lastRisk.hits.length});renderRisk();save(true);});
    $('#exportJson').addEventListener('click',()=>download(`职舵2027_完整备份_${Date.now()}.json`,JSON.stringify(state,null,2),'application/json'));
    $('#exportPlanHtml').addEventListener('click',()=>{const html=`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>职舵2027就业行动方案</title><style>body{font-family:system-ui,'Microsoft YaHei',sans-serif;max-width:1000px;margin:40px auto;padding:0 22px;color:#153246;line-height:1.65}table{width:100%;border-collapse:collapse}th,td{padding:9px;border:1px solid #d8e5ec;text-align:left}th{background:#e9f1f6}.eyebrow{color:#16779d;font-size:12px;font-weight:800;letter-spacing:.1em}.receipt{font-family:monospace;font-size:11px;color:#617a8a}</style><body>${planHtml()}</body></html>`;download(`职舵2027_就业行动方案_${Date.now()}.html`,html,'text/html;charset=utf-8');});
    $('#printPlan').addEventListener('click',()=>{navigate('export');setTimeout(()=>window.print(),100);});
    $('#importFile').addEventListener('change',e=>{const f=e.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result);if(!x.profile)throw new Error('缺少profile');state=normalizeState(x);addReceipt('state_imported',{name:f.name});renderAll();save(true);toast('备份已导入');}catch(err){toast('导入失败：文件结构不正确');}};r.readAsText(f);});
    $('#clearData').addEventListener('click',()=>{if(confirm('确定清空本机数据并恢复演示吗？此操作不可撤销，除非已有JSON备份。')){storage.removeItem(STORAGE_KEY);state=normalizeState(sealDemoEvidence(demoState()));addReceipt('local_data_cleared',{});renderAll();toast('本机数据已清空');}});
  }

  loadStored(); populateTrackSelects(); bindEvents(); renderAll();
})();
