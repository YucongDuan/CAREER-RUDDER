/*
 * DIKWP CAREER RUDDER / ZHIDUO 17.0.0
 * China 2027 Graduate Career Planning & Employment Decision Core
 * Dependency-free UMD module for browsers and Node.js.
 * SPDX-License-Identifier: Apache-2.0
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.ZhiduoCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const VERSION = '17.0.0';
  const MODE = 'ZHIDUO17_CHINA2027_GRADUATE_MULTI_WORLD_TRACK_PORTFOLIO_EVIDENCE_PIPELINE_OFFER_REALITY_CLOSURE';
  const DATA_AS_OF = '2026-09-02';

  const clamp = (v, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, Number(v) || 0));
  const round = (v, n = 4) => Number((Number(v) || 0).toFixed(n));
  const mean = arr => arr.length ? arr.reduce((a, b) => a + Number(b || 0), 0) / arr.length : 0;
  const sum = arr => arr.reduce((a, b) => a + Number(b || 0), 0);

  const SKILLS = [
    { id: 'quant', zh: '数量与数据', en: 'Quantitative & data' },
    { id: 'ai', zh: 'AI协作与验证', en: 'AI orchestration & verification' },
    { id: 'coding', zh: '代码/自动化', en: 'Coding & automation' },
    { id: 'communication', zh: '表达与协作', en: 'Communication & coordination' },
    { id: 'sales', zh: '客户与商业', en: 'Customer & commercial' },
    { id: 'research', zh: '研究与结构化分析', en: 'Research & structured analysis' },
    { id: 'execution', zh: '项目与现实交付', en: 'Project & real delivery' },
    { id: 'publicService', zh: '公共服务匹配', en: 'Public-service fit' },
    { id: 'field', zh: '现场/具身能力', en: 'Field & embodied capability' },
    { id: 'english', zh: '英语与跨文化', en: 'English & cross-cultural' },
    { id: 'proof', zh: '成果证据完整度', en: 'Evidence portfolio' }
  ];

  const WORLD_MODELS = [
    {
      id: 'normal_recruitment', zh: '常态招聘但结构变化', en: 'Normal hiring with structural change', weight: 0.27,
      description: '岗位仍存在，但AI工具、绩效标准与技能结构继续变化。'
    },
    {
      id: 'entry_compression', zh: '入门认知岗位压缩', en: 'Entry-level cognitive compression', weight: 0.23,
      description: '常规写作、分析、检索、初级代码与流程执行被Agent和Harness压缩。'
    },
    {
      id: 'macro_slowdown', zh: '宏观放缓与招聘收缩', en: 'Macro slowdown & hiring contraction', weight: 0.16,
      description: '企业减少HC、延长决策周期，实习转正和现金流优先级上升。'
    },
    {
      id: 'public_competition', zh: '公共部门竞争与数智化', en: 'Public-sector competition & digitisation', weight: 0.13,
      description: '考试竞争、岗位限制和数字化同步提高，编制不等于任务不变。'
    },
    {
      id: 'real_economy_resilience', zh: '实体产业与本地服务韧性', en: 'Real-economy & local-service resilience', weight: 0.13,
      description: '制造、能源、物流、现场交付、照护和客户关系相对更抗纯文本自动化。'
    },
    {
      id: 'agi_discontinuity', zh: '强AI/AGI突变', en: 'Strong-AI / AGI discontinuity', weight: 0.08,
      description: '大量认知劳动价值快速下降，现实行动、资源、关系、治理和退出权更重要。'
    }
  ];

  const MAJOR_CLUSTERS = [
    ['business', '经管类'], ['cs_engineering', '计算机/电子/工程类'], ['science', '理学/数学类'],
    ['humanities', '文史哲/语言类'], ['law_public', '法学/公共管理类'], ['education', '教育类'],
    ['health', '医学/生命科学类'], ['design', '艺术/设计类'], ['agriculture', '农林环境类'], ['other', '其他/复合专业']
  ];

  const TRACKS = [
    {
      id: 'private_ai_ops', zh: 'AI+业务运营/产品/流程', group: 'market',
      desc: '把业务问题、流程、数据、AI工具、人工复核和结果交付组织起来。',
      requirements: { quant: .48, ai: .72, coding: .35, communication: .62, sales: .48, research: .48, execution: .70, publicService: .20, field: .35, english: .42, proof: .62 },
      majorFit: { business: .92, cs_engineering: .82, science: .70, humanities: .72, law_public: .70, education: .65, health: .64, design: .75, agriculture: .68, other: .65 },
      world: { normal_recruitment: .82, entry_compression: .72, macro_slowdown: .64, public_competition: .62, real_economy_resilience: .74, agi_discontinuity: .56 },
      stability: .58, incomeSpeed: .78, cost: .28, reversibility: .88, evidenceYield: .88, competition: .72, intensity: .68, mobilityNeed: .55, formalEmployment: .78, delayMonths: 1.5,
      proof: ['流程诊断', 'AI辅助原型', '前后对比指标', '使用者确认']
    },
    {
      id: 'industrial_ops', zh: '制造/能源/物流/供应链运营', group: 'real_economy',
      desc: '进入具有物理流程、交付约束和长期产业链的真实经济岗位。',
      requirements: { quant: .58, ai: .48, coding: .28, communication: .56, sales: .42, research: .44, execution: .76, publicService: .22, field: .66, english: .38, proof: .58 },
      majorFit: { business: .86, cs_engineering: .86, science: .72, humanities: .48, law_public: .50, education: .40, health: .38, design: .50, agriculture: .78, other: .58 },
      world: { normal_recruitment: .76, entry_compression: .78, macro_slowdown: .66, public_competition: .58, real_economy_resilience: .91, agi_discontinuity: .68 },
      stability: .68, incomeSpeed: .74, cost: .30, reversibility: .74, evidenceYield: .76, competition: .58, intensity: .74, mobilityNeed: .72, formalEmployment: .86, delayMonths: 1.8,
      proof: ['现场调研', '流程/库存/交付数据', '降本增效证据', '跨部门协同记录']
    },
    {
      id: 'solution_sales', zh: '产业销售/解决方案/客户成功', group: 'market',
      desc: '以行业理解、客户问题、信任和结果交付连接技术与商业。',
      requirements: { quant: .36, ai: .48, coding: .20, communication: .82, sales: .86, research: .38, execution: .72, publicService: .18, field: .62, english: .46, proof: .58 },
      majorFit: { business: .94, cs_engineering: .68, science: .56, humanities: .80, law_public: .68, education: .62, health: .70, design: .72, agriculture: .68, other: .70 },
      world: { normal_recruitment: .80, entry_compression: .76, macro_slowdown: .60, public_competition: .50, real_economy_resilience: .84, agi_discontinuity: .64 },
      stability: .48, incomeSpeed: .88, cost: .20, reversibility: .86, evidenceYield: .84, competition: .66, intensity: .80, mobilityNeed: .68, formalEmployment: .74, delayMonths: 1.0,
      proof: ['客户访谈', '需求方案', '转化/续约/满意度', '复杂异议处理']
    },
    {
      id: 'finance_risk', zh: '财务/数据/风控/合规', group: 'market',
      desc: '从机械报表转向数据解释、内部控制、合规、风险与业务决策。',
      requirements: { quant: .72, ai: .54, coding: .42, communication: .54, sales: .26, research: .62, execution: .66, publicService: .32, field: .22, english: .48, proof: .64 },
      majorFit: { business: .91, cs_engineering: .64, science: .76, humanities: .40, law_public: .80, education: .32, health: .42, design: .28, agriculture: .50, other: .50 },
      world: { normal_recruitment: .74, entry_compression: .57, macro_slowdown: .64, public_competition: .68, real_economy_resilience: .70, agi_discontinuity: .48 },
      stability: .66, incomeSpeed: .72, cost: .35, reversibility: .72, evidenceYield: .72, competition: .78, intensity: .72, mobilityNeed: .50, formalEmployment: .90, delayMonths: 2.0,
      proof: ['数据分析', '风险案例', '控制矩阵', '业务建议与验证']
    },
    {
      id: 'tech_engineering', zh: '软件/工程/AI系统/安全', group: 'market',
      desc: '面向系统设计、可靠性、工具链、工程交付和高门槛技术问题。',
      requirements: { quant: .72, ai: .70, coding: .84, communication: .46, sales: .20, research: .62, execution: .78, publicService: .16, field: .30, english: .62, proof: .76 },
      majorFit: { business: .36, cs_engineering: .96, science: .83, humanities: .24, law_public: .26, education: .35, health: .40, design: .50, agriculture: .45, other: .42 },
      world: { normal_recruitment: .78, entry_compression: .60, macro_slowdown: .62, public_competition: .54, real_economy_resilience: .76, agi_discontinuity: .53 },
      stability: .56, incomeSpeed: .74, cost: .46, reversibility: .78, evidenceYield: .92, competition: .83, intensity: .82, mobilityNeed: .58, formalEmployment: .80, delayMonths: 2.0,
      proof: ['可运行项目', '测试与文档', '性能/可靠性指标', '代码与评审记录']
    },
    {
      id: 'state_owned', zh: '央国企/大型公共事业单位', group: 'institutional',
      desc: '重视组织匹配、专业资格、地域和流程纪律，同时保留数智化能力。',
      requirements: { quant: .46, ai: .40, coding: .28, communication: .62, sales: .32, research: .44, execution: .64, publicService: .58, field: .42, english: .36, proof: .54 },
      majorFit: { business: .86, cs_engineering: .92, science: .80, humanities: .64, law_public: .78, education: .58, health: .62, design: .48, agriculture: .72, other: .62 },
      world: { normal_recruitment: .76, entry_compression: .66, macro_slowdown: .72, public_competition: .65, real_economy_resilience: .82, agi_discontinuity: .55 },
      stability: .78, incomeSpeed: .66, cost: .34, reversibility: .61, evidenceYield: .54, competition: .82, intensity: .62, mobilityNeed: .66, formalEmployment: .96, delayMonths: 2.5,
      proof: ['岗位匹配简历', '专业项目', '组织与行业理解', '笔面试记录']
    },
    {
      id: 'civil_service', zh: '公务员/事业单位考试', group: 'public',
      desc: '只有在公共服务使命、岗位限制和考试准备具体时，才作为主路径。',
      requirements: { quant: .46, ai: .26, coding: .16, communication: .68, sales: .18, research: .56, execution: .54, publicService: .82, field: .38, english: .28, proof: .34 },
      majorFit: { business: .80, cs_engineering: .66, science: .58, humanities: .78, law_public: .95, education: .80, health: .70, design: .46, agriculture: .72, other: .64 },
      world: { normal_recruitment: .64, entry_compression: .55, macro_slowdown: .70, public_competition: .45, real_economy_resilience: .62, agi_discontinuity: .35 },
      stability: .84, incomeSpeed: .38, cost: .52, reversibility: .52, evidenceYield: .30, competition: .94, intensity: .74, mobilityNeed: .45, formalEmployment: .99, delayMonths: 7.0,
      proof: ['官方岗位表匹配', '模考趋势', '公共服务动机', '真实岗位访谈']
    },
    {
      id: 'postgraduate', zh: '目标明确的研究生路径', group: 'research',
      desc: '必须明确专业、导师/项目、研究问题和毕业后的能力增量，拒绝泛化延迟就业。',
      requirements: { quant: .58, ai: .46, coding: .32, communication: .48, sales: .14, research: .80, execution: .50, publicService: .24, field: .20, english: .58, proof: .52 },
      majorFit: { business: .72, cs_engineering: .84, science: .90, humanities: .82, law_public: .80, education: .82, health: .90, design: .70, agriculture: .84, other: .70 },
      world: { normal_recruitment: .62, entry_compression: .55, macro_slowdown: .61, public_competition: .58, real_economy_resilience: .54, agi_discontinuity: .39 },
      stability: .56, incomeSpeed: .18, cost: .70, reversibility: .48, evidenceYield: .55, competition: .82, intensity: .78, mobilityNeed: .52, formalEmployment: .20, delayMonths: 30.0,
      proof: ['具体研究问题', '导师/项目匹配', '方法能力样本', '学位增量与退出方案']
    },
    {
      id: 'grassroots', zh: '基层项目/西部计划/三支一扶等', group: 'public',
      desc: '以真实基层服务、现场能力和政策通道为主，不把项目名称等同于长期保障。',
      requirements: { quant: .32, ai: .34, coding: .16, communication: .70, sales: .22, research: .42, execution: .72, publicService: .80, field: .76, english: .22, proof: .48 },
      majorFit: { business: .76, cs_engineering: .66, science: .62, humanities: .82, law_public: .88, education: .92, health: .82, design: .64, agriculture: .92, other: .72 },
      world: { normal_recruitment: .65, entry_compression: .75, macro_slowdown: .72, public_competition: .62, real_economy_resilience: .88, agi_discontinuity: .72 },
      stability: .55, incomeSpeed: .55, cost: .22, reversibility: .76, evidenceYield: .80, competition: .64, intensity: .72, mobilityNeed: .82, formalEmployment: .62, delayMonths: 3.0,
      proof: ['基层问题记录', '服务结果', '利益相关方确认', '政策资格核验']
    },
    {
      id: 'education_care', zh: '教育/照护/社会服务创新', group: 'human_service',
      desc: '结合专业资格、真实关系、现场责任和AI辅助，避免把服务完全文本化。',
      requirements: { quant: .28, ai: .42, coding: .16, communication: .82, sales: .28, research: .50, execution: .72, publicService: .66, field: .78, english: .30, proof: .62 },
      majorFit: { business: .58, cs_engineering: .40, science: .46, humanities: .76, law_public: .72, education: .97, health: .92, design: .68, agriculture: .60, other: .62 },
      world: { normal_recruitment: .69, entry_compression: .79, macro_slowdown: .62, public_competition: .64, real_economy_resilience: .90, agi_discontinuity: .78 },
      stability: .60, incomeSpeed: .62, cost: .24, reversibility: .79, evidenceYield: .86, competition: .60, intensity: .76, mobilityNeed: .42, formalEmployment: .70, delayMonths: 2.0,
      proof: ['服务设计', '现场观察', '受益者反馈', '边界与伦理记录']
    },
    {
      id: 'microventure', zh: '微型创业/自由职业验证', group: 'venture',
      desc: '用低成本、低杠杆和真实付费验证需求，不鼓励毕业即高负债创业。',
      requirements: { quant: .42, ai: .62, coding: .34, communication: .72, sales: .80, research: .50, execution: .86, publicService: .18, field: .55, english: .38, proof: .78 },
      majorFit: { business: .92, cs_engineering: .78, science: .64, humanities: .80, law_public: .54, education: .72, health: .58, design: .86, agriculture: .76, other: .74 },
      world: { normal_recruitment: .70, entry_compression: .64, macro_slowdown: .52, public_competition: .44, real_economy_resilience: .77, agi_discontinuity: .61 },
      stability: .28, incomeSpeed: .50, cost: .58, reversibility: .80, evidenceYield: .95, competition: .72, intensity: .90, mobilityNeed: .50, formalEmployment: .25, delayMonths: 2.0,
      proof: ['真实付费', '单位经济', '客户复购/推荐', '有限责任与退出记录']
    },
    {
      id: 'bridge_internship', zh: '实习转正/见习/项目制过渡', group: 'bridge',
      desc: '在尚未获得正式Offer时，用可核验的真实工作连接学校与就业。',
      requirements: { quant: .36, ai: .48, coding: .28, communication: .60, sales: .40, research: .40, execution: .78, publicService: .32, field: .52, english: .34, proof: .50 },
      majorFit: { business: .88, cs_engineering: .88, science: .78, humanities: .78, law_public: .76, education: .80, health: .72, design: .84, agriculture: .80, other: .80 },
      world: { normal_recruitment: .78, entry_compression: .70, macro_slowdown: .72, public_competition: .58, real_economy_resilience: .80, agi_discontinuity: .62 },
      stability: .42, incomeSpeed: .76, cost: .18, reversibility: .94, evidenceYield: .90, competition: .58, intensity: .68, mobilityNeed: .58, formalEmployment: .45, delayMonths: 0.8,
      proof: ['真实任务', '主管反馈', '可公开成果', '转正或推荐证据']
    }
  ];

  const SKILL_KEYWORDS = {
    'Excel/表格': ['excel', 'vlookup', 'xlookup', 'power query', '数据透视表', '电子表格'],
    'SQL': ['sql', 'mysql', 'postgresql', '数据库查询'],
    'Python': ['python', 'pandas', 'numpy', '自动化脚本'],
    '数据分析': ['数据分析', '指标体系', '可视化', '统计分析', 'ab测试', 'a/b测试', '漏斗'],
    'AI工具': ['大模型', 'llm', 'chatgpt', '智能体', 'agent', 'prompt', '提示词', 'ai工作流', 'rag'],
    '项目管理': ['项目管理', '里程碑', '排期', '风险管理', '项目交付', 'pmp'],
    '产品': ['产品经理', '需求分析', '用户故事', 'prd', '原型', '竞品分析'],
    '运营': ['运营', '增长', '用户运营', '内容运营', '活动运营', '转化率', '留存'],
    '供应链': ['供应链', '采购', '库存', '物流', '计划', 's&op', '仓储'],
    '财务': ['财务分析', '会计', '预算', '成本核算', '审计', '报表'],
    '风控合规': ['风控', '合规', '内控', '风险评估', '反洗钱', '法务'],
    '销售': ['销售', '客户开发', '商机', '回款', '谈判', '解决方案销售'],
    '客户成功': ['客户成功', '续约', '客户满意度', '售后', '客诉'],
    '研究': ['研究', '调研', '文献', '实验设计', '访谈', '问卷'],
    '表达协作': ['沟通', '汇报', '跨部门', '协调', '演讲', '写作'],
    '英语': ['cet-4', 'cet4', 'cet-6', 'cet6', '雅思', '托福', '英语', 'english'],
    '代码工程': ['javascript', 'java', 'c++', 'git', 'docker', 'linux', 'api', '测试'],
    '设计': ['figma', 'ui', 'ux', '交互设计', '视觉设计', '用户研究'],
    '公共服务': ['公共服务', '基层治理', '政策分析', '行政管理', '公文'],
    '制造质量': ['精益生产', '质量管理', '六西格玛', 'mes', '工艺', '生产计划']
  };

  const SCAM_PATTERNS = [
    { level: 'critical', label: '索要密码/验证码', re: /(银行卡密码|网银密码|短信验证码|支付密码|共享屏幕.*银行)/i, advice: '立即停止，不提供任何密码或验证码。' },
    { level: 'critical', label: '贷款或培训贷', re: /(培训贷|求职贷|分期贷款|先贷款.*培训|贷款入职)/i, advice: '不要签署贷款或分期协议，向学校和监管渠道核验。' },
    { level: 'high', label: '付费内推/保证录用', re: /(付费内推|内推费|保证录用|包过面试|保offer|保录取)/i, advice: '正规招聘通常不以付费换取录用；通过企业官网和学校核验。' },
    { level: 'high', label: '先交押金/服装费/保证金', re: /(押金|保证金|服装费|工牌费|入职费|报名费|材料费).*?(转账|缴纳|支付)?/i, advice: '不向个人账户转账，不交不明费用。' },
    { level: 'critical', label: '传销/发展下线', re: /(发展下线|拉人头|团队计酬|层级返利|入会费)/i, advice: '高度危险，停止接触并保留证据。' },
    { level: 'critical', label: '刷单/垫资', re: /(刷单|垫资|做任务返现|充值返利|代付)/i, advice: '停止操作，不垫付资金。' },
    { level: 'high', label: '陌生App或远程控制', re: /(下载.*app|安装.*软件|远程控制|共享屏幕|开启屏幕共享)/i, advice: '只从企业官方渠道下载，不安装来源不明软件。' },
    { level: 'medium', label: '长期无薪试岗', re: /(无薪试岗|免费试工|试岗.*不发工资|先干.*再签合同)/i, advice: '核对劳动关系、期限、报酬和书面协议。' },
    { level: 'medium', label: '夸大收入与低门槛', re: /(轻松月入|日赚|零门槛高薪|在家躺赚|无需经验.*高薪)/i, advice: '对照市场薪酬，核验岗位、合同和用工主体。' },
    { level: 'medium', label: '证件原件扣押', re: /(扣押.*身份证|上交.*身份证原件|保管.*毕业证原件)/i, advice: '不要让用人方长期扣押身份证或证书原件。' }
  ];

  const DEFAULT_PROFILE = {
    id: 'cn-2027-business-demo', name: '2027届同学（演示）', degree: 'bachelor', schoolType: 'public_undergrad',
    majorCluster: 'business', major: '工商管理', graduationDate: '2027-06-30', currentCity: '海口', targetRegions: '海口、广州、深圳、成都',
    weeklyHours: 36, runwayMonths: 5, monthlyBudget: 1200, minimumMonthlyCash: 5000,
    stabilityPreference: .78, relocationFlexibility: .58, familyBurden: .58, healthEnergy: .72,
    publicServiceFit: .58, postgraduateSpecificity: .25, researchCommitment: .40, ventureEvidence: .20,
    mustFormalSocialInsurance: true, cannotHighDebt: true, nonNegotiables: '不接受高负债培训；不伪造经历；优先正式社保与可持续工作强度。',
    skills: { quant: .42, ai: .55, coding: .22, communication: .68, sales: .58, research: .48, execution: .52, publicService: .56, field: .48, english: .46, proof: .30 },
    evidenceCounts: { internships: 1, projects: 1, externalVerifications: 0, quantifiedStories: 1 },
    purpose: '在2027年毕业前形成一份可接受的就业结果，同时保留跨行业迁移、AI协作、现实交付与继续学习能力。'
  };

  function clone(x) { return JSON.parse(JSON.stringify(x)); }
  function stableStringify(value) {
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return '[' + value.map(stableStringify).join(',') + ']';
    return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + stableStringify(value[k])).join(',') + '}';
  }
  function fnv1a(str) {
    let h = 0x811c9dc5;
    for (let i = 0; i < String(str).length; i++) {
      h ^= String(str).charCodeAt(i);
      h = Math.imul(h, 0x01000193);
    }
    return ('00000000' + (h >>> 0).toString(16)).slice(-8);
  }

  function hashRecord(record) {
    const copy = clone(record || {});
    delete copy.hash;
    return fnv1a(stableStringify(copy));
  }

  function verifyHashChain(records = []) {
    let prev = 'GENESIS';
    const errors = [];
    (Array.isArray(records) ? records : []).forEach((record, index) => {
      if (record.prev !== prev) errors.push({ index, id: record.id || null, type: 'previous_hash_mismatch', expected: prev, actual: record.prev });
      const expectedHash = hashRecord(record);
      if (record.hash !== expectedHash) errors.push({ index, id: record.id || null, type: 'record_hash_mismatch', expected: expectedHash, actual: record.hash });
      prev = record.hash;
    });
    return { valid: errors.length === 0, count: Array.isArray(records) ? records.length : 0, head: prev, errors };
  }

  function normalizeWorlds(worlds) {
    const rows = (Array.isArray(worlds) && worlds.length ? worlds : WORLD_MODELS)
      .map(w => ({ ...w, weight: Math.max(0, Number(w.weight) || 0) }));
    const total = sum(rows.map(w => w.weight));
    if (total <= 0) {
      const equal = 1 / rows.length;
      return rows.map(w => ({ ...w, weight: equal }));
    }
    return rows.map(w => ({ ...w, weight: w.weight / total }));
  }

  function daysBetween(a, b) {
    const A = new Date(a); const B = new Date(b);
    return Math.ceil((B.setHours(12,0,0,0) - A.setHours(12,0,0,0)) / 86400000);
  }

  function phaseFor(date, graduationDate = '2027-06-30') {
    const d = new Date(date || new Date());
    const ymd = d.toISOString().slice(0, 10);
    const grad = new Date(graduationDate);
    const daysToGrad = daysBetween(ymd, graduationDate);
    let id = 'post_graduation', zh = '离校后连续性阶段', priority = '登记公共就业服务、见习/项目过渡、继续投递并保护权益';
    if (ymd <= '2026-10-31') { id = 'autumn_main'; zh = '秋招主战场'; priority = '立即进入企业/央国企投递、笔试和面试，不再等待“准备完美”'; }
    else if (ymd <= '2026-12-31') { id = 'autumn_late_exam'; zh = '秋招后段与考试节点'; priority = '保住面试管道，同时只按官方公告处理研考、国考及各地招考'; }
    else if (ymd <= '2027-02-28') { id = 'winter_reset'; zh = '寒假重构期'; priority = '复盘秋招数据、补证据、准备春招和地域/行业再分配'; }
    else if (ymd <= '2027-04-30') { id = 'spring_main'; zh = '春招主战场'; priority = '扩大行业与地域、使用实习/见习/项目桥接，避免只等一个结果'; }
    else if (ymd <= graduationDate) { id = 'graduation_close'; zh = '毕业闭环期'; priority = '完成Offer、合同、档案和毕业事项；未落实者启动桥接方案'; }
    return { id, zh, priority, daysToGrad, graduationDate: grad.toISOString().slice(0,10) };
  }

  function evidenceReadiness(profile, context = {}) {
    const c = profile.evidenceCounts || {};
    const counts = clamp((Number(c.internships || 0) * .18 + Number(c.projects || 0) * .14 + Number(c.externalVerifications || 0) * .22 + Number(c.quantifiedStories || 0) * .12), 0, .75);
    const ledger = clamp((context.evidenceCount || 0) / 8, 0, .25);
    return clamp(.52 * clamp(profile.skills?.proof) + counts + ledger);
  }

  function skillFit(profile, track) {
    let weighted = 0, total = 0;
    for (const [k, req] of Object.entries(track.requirements)) {
      const r = Math.max(.01, req);
      const got = clamp(profile.skills?.[k]);
      const fulfil = Math.min(1.12, got / r);
      weighted += fulfil * r;
      total += r;
    }
    return clamp(weighted / (total || 1));
  }

  function constraintAssessment(profile, track, readiness) {
    const blockers = [], cautions = [];
    let penalty = 0;
    const runway = Number(profile.runwayMonths || 0);
    if (runway < Math.min(6, track.delayMonths) && track.incomeSpeed < .45) {
      penalty += .14; cautions.push('经济缓冲不足以安全覆盖该路径的收入延迟');
    }
    if (profile.cannotHighDebt && track.cost > .62) { penalty += .08; cautions.push('路径成本较高，与“不高负债”约束冲突'); }
    if (profile.mustFormalSocialInsurance && track.formalEmployment < .45) { penalty += .08; cautions.push('正式社保确定性较弱'); }
    if (profile.healthEnergy < track.intensity - .18) { penalty += .08; cautions.push('当前精力与路径强度不匹配'); }
    if (profile.relocationFlexibility < track.mobilityNeed - .25) { penalty += .06; cautions.push('地域灵活性可能限制机会'); }
    if (track.id === 'postgraduate' && profile.postgraduateSpecificity < .55) { blockers.push('研究生目标尚未具体到专业、导师/项目和能力增量'); penalty += .18; }
    if (track.id === 'civil_service' && profile.publicServiceFit < .48) { blockers.push('公共服务使命匹配不足，不宜作为主路径'); penalty += .16; }
    if (track.id === 'microventure' && (runway < 6 || readiness < .45)) { blockers.push('缺少足够经济缓冲或真实付费证据，不宜毕业即主押创业'); penalty += .18; }
    if (track.id === 'tech_engineering' && clamp(profile.skills?.coding) < .38) { cautions.push('工程基础不足，需要先用可运行项目补证据'); penalty += .10; }
    return { penalty: clamp(penalty, 0, .35), blockers, cautions, mainAdmissible: blockers.length === 0 };
  }

  function evaluateTrack(profile, track, worlds = WORLD_MODELS, context = {}, date = new Date()) {
    const ws = normalizeWorlds(worlds);
    const sFit = skillFit(profile, track);
    const mFit = track.majorFit[profile.majorCluster] ?? .58;
    const ready = evidenceReadiness(profile, context);
    const stabilityFit = 1 - Math.abs(clamp(profile.stabilityPreference) - track.stability);
    const mobilityFit = 1 - Math.max(0, track.mobilityNeed - clamp(profile.relocationFlexibility));
    const incomeFit = clamp(.52 * track.incomeSpeed + .48 * Math.min(1, (Number(profile.runwayMonths || 0) + 1) / Math.max(1, track.delayMonths + 1)));
    const pref = clamp(.42 * stabilityFit + .28 * mobilityFit + .30 * incomeFit);
    const constraints = constraintAssessment(profile, track, ready);
    const phase = phaseFor(date, profile.graduationDate);
    let urgency = .55;
    if (phase.id === 'autumn_main' && ['market','institutional','bridge'].includes(track.group)) urgency = .95;
    if (phase.id === 'autumn_main' && ['public','research'].includes(track.group)) urgency = .70;
    if (phase.id === 'spring_main' && ['market','bridge','real_economy'].includes(track.group)) urgency = .95;
    if (phase.id === 'graduation_close' && track.incomeSpeed > .6) urgency = .92;

    const scores = {};
    for (const w of ws) {
      const base = track.world[w.id] ?? .5;
      scores[w.id] = clamp(.40 * base + .24 * sFit + .12 * mFit + .10 * ready + .08 * pref + .06 * urgency - constraints.penalty);
    }
    const expected = sum(ws.map(w => w.weight * scores[w.id]));
    const worst = Math.min(...Object.values(scores));
    const optionValue = clamp(.52 * track.reversibility + .48 * track.evidenceYield);
    const lockIn = clamp(.38 * track.cost + .34 * (track.delayMonths / 30) + .28 * (1 - track.reversibility));
    const advisoryIndex = clamp(.26 * expected + .26 * worst + .17 * optionValue + .12 * ready + .09 * pref + .10 * urgency - .09 * lockIn);
    return {
      trackId: track.id, trackName: track.zh, group: track.group, skillFit: round(sFit), majorFit: round(mFit), readiness: round(ready),
      preferenceFit: round(pref), urgency: round(urgency), expected: round(expected), worst: round(worst), optionValue: round(optionValue),
      lockIn: round(lockIn), advisoryIndex: round(advisoryIndex), worldScores: Object.fromEntries(Object.entries(scores).map(([k,v]) => [k, round(v)])),
      mainAdmissible: constraints.mainAdmissible, blockers: constraints.blockers, cautions: constraints.cautions,
      gaps: topSkillGaps(profile, track, 4)
    };
  }

  function topSkillGaps(profile, track, n = 4) {
    return Object.entries(track.requirements)
      .map(([id, req]) => ({ id, name: SKILLS.find(s => s.id === id)?.zh || id, gap: Math.max(0, req - clamp(profile.skills?.[id])), required: req, current: clamp(profile.skills?.[id]) }))
      .filter(x => x.gap > .04).sort((a,b) => b.gap - a.gap).slice(0,n).map(x => ({ ...x, gap: round(x.gap), required: round(x.required), current: round(x.current) }));
  }

  function evaluateAllTracks(profile, worlds = WORLD_MODELS, context = {}, date = new Date()) {
    return TRACKS.map(t => evaluateTrack(profile, t, worlds, context, date)).sort((a,b) => b.advisoryIndex - a.advisoryIndex);
  }

  function dominates(a, b) {
    const dims = ['worst','expected','optionValue','readiness'];
    const atLeast = dims.every(k => a[k] >= b[k] - 1e-9) && a.lockIn <= b.lockIn + 1e-9;
    const strict = dims.some(k => a[k] > b[k] + 1e-9) || a.lockIn < b.lockIn - 1e-9;
    return atLeast && strict;
  }
  function paretoFrontier(evals) { return evals.filter(a => !evals.some(b => b !== a && dominates(b, a))); }

  function worldDistance(trackA, trackB) {
    const keys = WORLD_MODELS.map(w => w.id);
    return mean(keys.map(k => Math.abs((trackA.world[k] || .5) - (trackB.world[k] || .5))));
  }

  function recommendPortfolio(profile, worlds = WORLD_MODELS, context = {}, date = new Date()) {
    const evaluations = evaluateAllTracks(profile, worlds, context, date);
    const admissible = evaluations.filter(e => e.mainAdmissible);
    let main = admissible[0] || evaluations[0];
    const mainTrack = TRACKS.find(t => t.id === main.trackId);
    if ((profile.runwayMonths || 0) < 3) {
      const fast = admissible.find(e => (TRACKS.find(t => t.id === e.trackId)?.incomeSpeed || 0) >= .65);
      if (fast) main = fast;
    }
    const mt = TRACKS.find(t => t.id === main.trackId);
    const candidates = evaluations.filter(e => e.trackId !== main.trackId && e.mainAdmissible);
    let hedge = candidates.map(e => {
      const t = TRACKS.find(x => x.id === e.trackId);
      const groupBonus = t.group === mt.group ? 0 : .18;
      const dist = worldDistance(mt, t);
      const score = .56 * e.advisoryIndex + .18 * e.optionValue + .16 * dist + groupBonus;
      return { e, score };
    }).sort((a,b) => b.score - a.score)[0]?.e || candidates[0] || main;

    const readiness = evidenceReadiness(profile, context);
    let proofShare = readiness < .30 ? 25 : readiness < .52 ? 20 : 15;
    let hedgeShare = 20;
    let mainShare = 100 - proofShare - hedgeShare;
    if (['public','research'].includes(mt.group)) { hedgeShare = 30; proofShare = Math.max(proofShare, 20); mainShare = 50; }
    if ((profile.runwayMonths || 0) < 3) { hedgeShare = 25; mainShare = 55; proofShare = 20; }

    const allocations = [
      { id: main.trackId, name: main.trackName, role: '主路径', share: mainShare },
      { id: hedge.trackId, name: hedge.trackName, role: '异质对冲', share: hedgeShare },
      { id: 'common_proof', name: '共同底座：作品、求职管道与AI协作证据', role: '不可省略', share: proofShare }
    ];
    return {
      generatedAt: new Date(date).toISOString(), phase: phaseFor(date, profile.graduationDate), main, hedge, allocations,
      frontier: paretoFrontier(evaluations).map(x => x.trackId), evaluations,
      stopRules: buildStopRules(profile, main, hedge, context)
    };
  }

  function buildStopRules(profile, main, hedge, context = {}) {
    const rules = [
      '连续20份高匹配投递无任何笔试/面试信号：停止盲投，重做目标职位、简历证据和渠道。',
      '累计6次正式面试无Offer：停止只练“话术”，逐题复盘证据、岗位匹配和真实案例。',
      '任何机构要求付费内推、培训贷、押金或提供密码/验证码：立即停止并核验。',
      '任何经历无法提供文件、作品、数据或第三方确认：不得写成已完成事实。'
    ];
    if (main.trackId === 'postgraduate') rules.push('在官方报名节点前仍说不清专业、导师/项目、研究问题和退出方案：研究生路径降为对冲。');
    if (main.trackId === 'civil_service') rules.push('三轮模考没有趋势改善，且公共服务使命匹配未增强：不得继续把考试当作唯一通道。');
    if (main.trackId === 'microventure') rules.push('4周内没有真实付费或明确复购证据：停止扩大投入，不举债。');
    if ((profile.runwayMonths || 0) < 3) rules.push('经济缓冲低于3个月：任何延迟收入路径不得独占每周投入。');
    return rules;
  }

  function applicationMetrics(applications = []) {
    const active = applications.filter(a => !['rejected','withdrawn'].includes(a.status));
    const applied = applications.filter(a => !['saved','target'].includes(a.status));
    const interview = applications.filter(a => ['interview1','interview2','final','offer'].includes(a.status));
    const offers = applications.filter(a => a.status === 'offer');
    const responses = applications.filter(a => ['test','interview1','interview2','final','offer','rejected'].includes(a.status));
    return {
      total: applications.length, active: active.length, applied: applied.length, responses: responses.length, interviews: interview.length, offers: offers.length,
      responseRate: applied.length ? round(responses.length / applied.length) : 0,
      interviewRate: applied.length ? round(interview.length / applied.length) : 0,
      offerRate: applied.length ? round(offers.length / applied.length) : 0
    };
  }

  function deadlineState(date, today = new Date()) {
    if (!date) return { label: '未设置', level: 'muted', days: null };
    const days = daysBetween(new Date(today).toISOString().slice(0,10), date);
    if (days < 0) return { label: `已过期${Math.abs(days)}天`, level: 'danger', days };
    if (days <= 3) return { label: `${days}天内`, level: 'danger', days };
    if (days <= 10) return { label: `${days}天`, level: 'warn', days };
    return { label: `${days}天`, level: 'good', days };
  }

  function nextActions(state, date = new Date()) {
    const p = state.profile;
    const phase = phaseFor(date, p.graduationDate);
    const metrics = applicationMetrics(state.applications || []);
    const plan = recommendPortfolio(p, state.worlds || WORLD_MODELS, { evidenceCount: (state.evidence || []).length }, date);
    const actions = [];
    if (phase.id === 'autumn_main' && metrics.applied < 15) actions.push({ priority: 1, title: '建立首批20个高匹配岗位池', why: '2027届招聘已经启动，等待会直接损失批次机会', evidence: '公司、岗位、截止日、来源、匹配理由' });
    if (metrics.applied < 5) actions.push({ priority: 1, title: '完成并投递两版证据型简历', why: '一版面向主路径，一版面向异质对冲', evidence: '每条经历含动作、对象、结果和可核验证据' });
    if ((state.evidence || []).length < 3) actions.push({ priority: 1, title: '启动14天成果证据冲刺', why: '没有真实证据，任何AI润色都只会放大空洞', evidence: '1个可运行/可查看成果、1个指标、1个第三方确认' });
    if (metrics.applied >= 10 && metrics.responseRate < .08) actions.push({ priority: 1, title: '暂停扩量，重做定位和简历匹配', why: '投递量已出现但反馈过低', evidence: 'JD覆盖率、岗位层级、学校/地域约束复盘' });
    if (metrics.interviews > 0 && metrics.offers === 0) actions.push({ priority: 2, title: '对最近两次面试做逐题证据复盘', why: '面试不应只练表达，要检验案例与岗位的因果连接', evidence: '问题、原回答、缺证据、改进后的真实案例' });
    actions.push({ priority: 2, title: `本周主路径：${plan.main.trackName}`, why: `分配${plan.allocations[0].share}%可用时间`, evidence: TRACKS.find(t => t.id === plan.main.trackId)?.proof.slice(0,2).join('、') || '真实成果' });
    actions.push({ priority: 3, title: `保留对冲：${plan.hedge.trackName}`, why: `分配${plan.allocations[1].share}%可用时间，避免单一路径失败`, evidence: '一项官方资格核验或一项真实投递/访谈' });
    return actions.sort((a,b) => a.priority - b.priority).slice(0,7);
  }

  function normalizeText(s) { return String(s || '').toLowerCase().replace(/[\s\u3000]+/g, ' '); }
  function categoriesInText(text) {
    const t = normalizeText(text);
    const found = [];
    for (const [cat, words] of Object.entries(SKILL_KEYWORDS)) {
      const hits = words.filter(w => t.includes(w.toLowerCase()));
      if (hits.length) found.push({ category: cat, hits: [...new Set(hits)] });
    }
    return found;
  }

  function matchJD(jdText, resumeText) {
    const jdCats = categoriesInText(jdText);
    const cvCats = categoriesInText(resumeText);
    const cvSet = new Set(cvCats.map(x => x.category));
    const matched = jdCats.filter(x => cvSet.has(x.category));
    const missing = jdCats.filter(x => !cvSet.has(x.category));
    const numbers = (String(resumeText || '').match(/\d+(?:\.\d+)?%?|[一二三四五六七八九十百]+(?:个|次|项|人|天|月)/g) || []).length;
    const actionVerbs = ['负责','完成','推动','设计','搭建','优化','分析','交付','协调','实现','降低','提升','增长','验证'];
    const verbCount = actionVerbs.filter(v => String(resumeText || '').includes(v)).length;
    const coverage = jdCats.length ? matched.length / jdCats.length : 0;
    const evidenceQuality = clamp(.55 * Math.min(1, numbers / 5) + .45 * Math.min(1, verbCount / 6));
    return {
      coverage: round(coverage), evidenceQuality: round(evidenceQuality), matched, missing,
      warnings: [
        ...(jdCats.length === 0 ? ['未识别到足够岗位关键词，请粘贴完整JD。'] : []),
        ...(String(resumeText || '').length < 120 ? ['简历文本过短，无法形成可靠匹配。'] : []),
        ...(evidenceQuality < .35 ? ['简历缺少数量、动作和结果证据；不要用AI虚构数字。'] : [])
      ],
      questions: missing.slice(0,6).map(x => `你是否有真实经历能证明“${x.category}”？有则补充对象、动作、结果和证据；没有则不要伪造。`)
    };
  }

  function scanRecruitmentRisk(text) {
    const hits = SCAM_PATTERNS.filter(p => p.re.test(String(text || ''))).map(p => ({ level: p.level, label: p.label, advice: p.advice }));
    const points = hits.reduce((a,h) => a + (h.level === 'critical' ? 4 : h.level === 'high' ? 3 : 1.5), 0);
    const score = clamp(points / 12);
    const level = hits.some(h => h.level === 'critical') ? 'critical' : hits.some(h => h.level === 'high') ? 'high' : hits.length ? 'medium' : 'low';
    return { score: round(score), level, hits, nonClaim: '文本扫描只能提示风险，不能单独证明对方违法或岗位虚假；应通过企业官网、学校和监管渠道核验。' };
  }

  function offerVector(offer, profile = DEFAULT_PROFILE) {
    const monthlyCashProxy = Number(offer.monthlySalary || 0) * Number(offer.salaryMonths || 12) / 12 + Number(offer.annualBonus || 0) / 12 + Number(offer.monthlyHousingSupport || 0) - Number(offer.monthlyEssentialCost || 0);
    const cash = clamp((monthlyCashProxy - Math.max(0, Number(profile.minimumMonthlyCash || 0) * .4)) / Math.max(1, Number(profile.minimumMonthlyCash || 5000) * 1.4));
    const health = clamp(1 - Math.max(0, Number(offer.weeklyHours || 45) - 40) / 45 - Math.max(0, Number(offer.commuteMinutes || 45) - 30) / 180);
    const rights = clamp(mean([offer.contractClarity, offer.socialInsurance, offer.overtimeClarity, offer.exitReversibility]));
    const growth = clamp(mean([offer.learning, offer.managerQuality, offer.taskOwnership, offer.transferability]));
    const aiResilience = clamp(1 - Number(offer.aiSubstitutionRisk || .5) * .65 + Number(offer.fieldRelation || .4) * .25 + Number(offer.taskOwnership || .5) * .20);
    const location = clamp(offer.locationFit ?? .5);
    const stability = clamp(mean([offer.organisationStability, offer.contractClarity, offer.socialInsurance]));
    const robust = Math.min(cash, health, rights, growth, aiResilience, location, stability);
    const redFlags = [];
    if (offer.contractClarity < .45) redFlags.push('合同与岗位边界不清');
    if (offer.socialInsurance < .45) redFlags.push('社保公积金安排不清或不足');
    if (Number(offer.weeklyHours || 0) > 60) redFlags.push('工作时长高于可持续区间');
    if (offer.aiSubstitutionRisk > .78 && offer.taskOwnership < .45) redFlags.push('任务高度可自动化且缺少责任所有权');
    if (monthlyCashProxy < Number(profile.minimumMonthlyCash || 0)) redFlags.push('现金结余代理值低于个人底线');
    return { cash: round(cash), health: round(health), rights: round(rights), growth: round(growth), aiResilience: round(aiResilience), location: round(location), stability: round(stability), robust: round(robust), monthlyCashProxy: round(monthlyCashProxy, 2), redFlags };
  }

  function offerPareto(offers, profile = DEFAULT_PROFILE) {
    const rows = offers.map(o => ({ ...o, vector: offerVector(o, profile) }));
    const keys = ['cash','health','rights','growth','aiResilience','location','stability'];
    return rows.filter(a => !rows.some(b => b.id !== a.id && keys.every(k => b.vector[k] >= a.vector[k] - 1e-9) && keys.some(k => b.vector[k] > a.vector[k] + 1e-9)));
  }

  function buildDecisionGates(state, date = new Date()) {
    const metrics = applicationMetrics(state.applications || []);
    const evidenceCount = (state.evidence || []).length;
    return [
      { date: '2026-09-15', name: '秋招启动门', continueIf: ['至少20个目标岗位', '两版证据型简历', '至少5份高匹配投递'], pivotIf: ['仍在等待“准备好”', '只搜集信息不投递'] },
      { date: '2026-10-15', name: '渠道与简历门', continueIf: ['累计20—35份高匹配投递', '出现笔试/面试/有效回复', '至少3条可核验证据'], pivotIf: ['20份以上无信号', '岗位高度同质且都不匹配专业/地域'] },
      { date: '2026-11-20', name: '主路径证据门', continueIf: ['主路径出现可量化进展', '考试类只按官方公告完成报名和资格核验'], pivotIf: ['只剩情绪性坚持', '没有可验证进步趋势'] },
      { date: '2027-02-20', name: '春招重构门', continueIf: ['形成新行业/新地域岗位池', '完成一个补缺作品或实习'], pivotIf: ['完全复用秋招失败策略', '没有扩大异质机会'] },
      { date: '2027-04-30', name: '毕业前保障门', continueIf: ['至少一个Offer或高概率流程', '合同、社保、城市成本已核验'], pivotIf: ['仍只等待单一单位', '经济缓冲不足却拒绝桥接方案'] },
      { date: '2027-06-15', name: '离校连续性门', continueIf: ['就业/升学/项目/见习至少有一条现实入口', '档案、合同、报到与权益事项清楚'], pivotIf: ['无入口且未登记公共就业服务', '接受需要付费或高风险的伪机会'] }
    ].map(g => ({ ...g, deadline: deadlineState(g.date, date), currentMetrics: { ...metrics, evidenceCount } }));
  }

  function makeCareerPlan(state, date = new Date()) {
    const context = { evidenceCount: (state.evidence || []).length };
    const portfolio = recommendPortfolio(state.profile, state.worlds || WORLD_MODELS, context, date);
    return {
      schema: 'dikwp.zhiduo.career-plan.v1', version: VERSION, mode: MODE, dataAsOf: DATA_AS_OF,
      generatedAt: new Date(date).toISOString(), profile: clone(state.profile), phase: phaseFor(date, state.profile.graduationDate),
      worldModels: normalizeWorlds(state.worlds || WORLD_MODELS), portfolio,
      applicationMetrics: applicationMetrics(state.applications || []), applications: clone(state.applications || []),
      evidence: clone(state.evidence || []), deadlines: clone(state.deadlines || []), offers: (state.offers || []).map(o => ({ ...o, evaluation: offerVector(o, state.profile) })),
      nextActions: nextActions(state, date), decisionGates: buildDecisionGates(state, date),
      integrity: { evidence: verifyHashChain(state.evidence || []), receipts: verifyHashChain(state.receipts || []) },
      invariants: {
        automatedHumanWorthRanking: 0, automatedHiringDecision: 0, fakeExperienceGeneration: 0,
        externalAutomaticApplication: 0, externalAutomaticValueTransfer: 0, userRevocationPrecedence: 1,
        scenarioWeightsAreForecastProbabilities: 0
      },
      nonClaims: [
        '本系统不预测个人必然录取、就业、编制、薪酬或职业寿命。',
        '路径排序是透明的决策支持，不是对人的价值排名。',
        '2027年招考和招聘日期必须以主管部门、学校和用人单位最新正式公告为准。',
        'AI可辅助分析和表达，但不得生成不存在的经历、数字、客户、论文或证书。'
      ]
    };
  }

  return {
    VERSION, MODE, DATA_AS_OF, SKILLS, WORLD_MODELS, MAJOR_CLUSTERS, TRACKS, SKILL_KEYWORDS, SCAM_PATTERNS, DEFAULT_PROFILE,
    clamp, round, mean, sum, clone, stableStringify, fnv1a, hashRecord, verifyHashChain, normalizeWorlds, daysBetween, phaseFor, evidenceReadiness, skillFit,
    topSkillGaps, evaluateTrack, evaluateAllTracks, paretoFrontier, recommendPortfolio, applicationMetrics, deadlineState, nextActions,
    categoriesInText, matchJD, scanRecruitmentRisk, offerVector, offerPareto, buildDecisionGates, makeCareerPlan
  };
});
